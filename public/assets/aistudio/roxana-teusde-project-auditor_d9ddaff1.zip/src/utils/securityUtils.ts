/**
 * Supabase Schema, Security and RLS (Row Level Security) generator
 * for ROXANA TEUSDE PFA (BUIE) database
 */

export interface SecurityPolicySummary {
  tableName: string;
  rlsEnabled: boolean;
  publicSelect: boolean;
  publicInsert: boolean;
  adminUpdate: boolean;
  adminDelete: boolean;
  description: string;
}

export function isValidSupabaseUrl(url: string): boolean {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' && parsed.hostname.includes('.supabase.co');
  } catch {
    return false;
  }
}

export function isValidSupabaseKey(key: string): boolean {
  if (!key) return false;
  const parts = key.trim().split('.');
  return parts.length === 3 && parts[0].length > 10;
}

export function getSecurityAudit(): SecurityPolicySummary[] {
  return [
    {
      tableName: 'bookings',
      rlsEnabled: true,
      publicSelect: false,
      publicInsert: true, // Clienții pot trimite programări
      adminUpdate: true, // Doar administratorul autentificat poate confirma/anula
      adminDelete: true, // Doar administratorul poate șterge
      description: 'Programările conțin date confidențiale (telefon, email, note). Doar administratorul are acces de citire și modificare.',
    },
    {
      tableName: 'reviews',
      rlsEnabled: true,
      publicSelect: true, // Publicul vede doar recenziile aprobate (approved = true)
      publicInsert: true, // Clienții pot adăuga recenzii noi pentru moderare
      adminUpdate: true, // Doar adminul poate aproba sau edita
      adminDelete: true, // Doar adminul poate șterge spam-ul
      description: 'Recenziile sunt moderate. Doar recenziile cu approved = true sunt vizibile public pe site.',
    },
    {
      tableName: 'gallery_items',
      rlsEnabled: true,
      publicSelect: true, // Publicul vede fotografiile și videoclipurile
      publicInsert: false, // Doar adminul poate încărca media
      adminUpdate: true, // Doar adminul poate schimba imaginile sau titlurile
      adminDelete: true, // Doar adminul poate șterge
      description: 'Galeria foto-video este publică pentru vizualizare. Modificarea și adăugarea de conținut necesită autentificare.',
    },
    {
      tableName: 'admin_auth_audit',
      rlsEnabled: true,
      publicSelect: false, // Jurnalul de securitate este strict confidențial
      publicInsert: true, // Sistemul înregistrează încercările de login
      adminUpdate: false, // Nimeni nu poate modifica jurnalul de securitate (audit imutabil)
      adminDelete: false, // Nu se șterg înregistrările de audit
      description: 'Jurnal de audit pentru toate autentificările (reușite și eșuate) ale administratorului PFA.',
    },
    {
      tableName: 'pfa_settings',
      rlsEnabled: true,
      publicSelect: true, // Datele publice PFA (CUI, telefon, orar) sunt vizibile public
      publicInsert: false, // Doar admin
      adminUpdate: true, // Doar adminul poate actualiza datele firmei
      adminDelete: false,
      description: 'Datele de identificare PFA, orarul de lucru și datele de contact oficiale.',
    },
  ];
}

export function generateSupabaseSQLSchema(): string {
  return `-- ==============================================================================
-- SCHEMA & ROW LEVEL SECURITY (RLS) PENTRU ROXANA TEUSDE PFA (BUIE)
-- Bază de date PostgreSQL / Supabase
-- ==============================================================================

-- 1. Tabel: bookings (Programări Frizerie & Barbershop)
CREATE TABLE IF NOT EXISTS public.bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reference_code VARCHAR(32) NOT NULL UNIQUE,
    client_name VARCHAR(150) NOT NULL,
    client_email VARCHAR(150) NOT NULL,
    client_phone VARCHAR(50) NOT NULL,
    service_id VARCHAR(50) NOT NULL,
    service_name VARCHAR(150) NOT NULL,
    barber_name VARCHAR(100) DEFAULT 'Roxana Teușde (Buie)',
    event_date DATE NOT NULL,
    event_time VARCHAR(20) NOT NULL,
    location VARCHAR(200) DEFAULT 'Atelier Tileagd',
    guests_count INT DEFAULT 1,
    estimated_total NUMERIC(10, 2) DEFAULT 0,
    deposit_amount NUMERIC(10, 2) DEFAULT 0,
    notes TEXT,
    addons JSONB DEFAULT '{}'::jsonb,
    status VARCHAR(30) DEFAULT 'in_asteptare' CHECK (status IN ('in_asteptare', 'confirmat', 'finalizat', 'anulat')),
    admin_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. Tabel: reviews (Recenzii & Păreri Clienți)
CREATE TABLE IF NOT EXISTS public.reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    author_name VARCHAR(150) NOT NULL,
    role_or_event VARCHAR(100) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    text TEXT NOT NULL,
    event_date VARCHAR(50),
    avatar_url TEXT,
    approved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. Tabel: gallery_items (Portofoliu Foto & Video Frizerie)
CREATE TABLE IF NOT EXISTS public.gallery_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    media_type VARCHAR(20) NOT NULL CHECK (media_type IN ('photo', 'video')),
    media_url TEXT NOT NULL,
    thumbnail_url TEXT,
    aspect_ratio VARCHAR(20) DEFAULT 'square',
    featured BOOLEAN DEFAULT FALSE,
    order_index INT DEFAULT 0,
    description TEXT,
    event_date VARCHAR(50),
    client_names VARCHAR(150),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Tabel: admin_auth_audit (Jurnal de Securitate Autentificări Admin)
CREATE TABLE IF NOT EXISTS public.admin_auth_audit (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(150) NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('SUCCESS', 'FAILED', 'LOGOUT')),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    user_agent TEXT,
    city VARCHAR(100) DEFAULT 'Tileagd, Bihor',
    failure_reason TEXT
);

-- 5. Tabel: pfa_settings (Informații Oficiale PFA ROXANA TEUSDE BUIE)
CREATE TABLE IF NOT EXISTS public.pfa_settings (
    id VARCHAR(50) PRIMARY KEY DEFAULT 'current',
    brand_name VARCHAR(150) NOT NULL DEFAULT 'Roxana Teusde PFA (Buie)',
    owner_name VARCHAR(150) NOT NULL DEFAULT 'Roxana Teușde (Buie)',
    cui VARCHAR(50) NOT NULL DEFAULT '48920194',
    reg_com VARCHAR(50) NOT NULL DEFAULT 'F05/124/2023',
    address VARCHAR(200) NOT NULL DEFAULT 'Strada Trandafirilor 1099, 417585 Tileagd, Bihor',
    phone VARCHAR(50) NOT NULL DEFAULT '+40 751 676 420',
    email VARCHAR(100) NOT NULL DEFAULT 'contact@roxanateusde.ro',
    hours_weekday VARCHAR(100) NOT NULL DEFAULT '09:00 - 16:00',
    hours_saturday VARCHAR(100) NOT NULL DEFAULT '09:00 - 13:00',
    hours_sunday VARCHAR(50) NOT NULL DEFAULT 'Închis',
    about_bio TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- ==============================================================================
-- ACTIVARE ROW LEVEL SECURITY (RLS)
-- ==============================================================================
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gallery_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_auth_audit ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pfa_settings ENABLE ROW LEVEL SECURITY;

-- Politici RLS bookings
CREATE POLICY "Public pot crea programari" ON public.bookings FOR INSERT WITH CHECK (true);
CREATE POLICY "Doar admin citeste programarile" ON public.bookings FOR SELECT TO authenticated USING (true);
CREATE POLICY "Doar admin actualizeaza programarile" ON public.bookings FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Doar admin sterge programarile" ON public.bookings FOR DELETE TO authenticated USING (true);

-- Politici RLS reviews
CREATE POLICY "Publicul vede recenziile aprobate" ON public.reviews FOR SELECT USING (approved = true OR auth.role() = 'authenticated');
CREATE POLICY "Oricine poate trimite o recenzie" ON public.reviews FOR INSERT WITH CHECK (true);
CREATE POLICY "Admin poate actualiza recenziile" ON public.reviews FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admin poate sterge recenziile" ON public.reviews FOR DELETE TO authenticated USING (true);

-- Politici RLS gallery_items
CREATE POLICY "Publicul vede portofoliul" ON public.gallery_items FOR SELECT USING (true);
CREATE POLICY "Doar admin gestioneaza galeria" ON public.gallery_items FOR ALL TO authenticated USING (true);

-- Politici RLS admin_auth_audit
CREATE POLICY "Sistemul inregistreaza incercarile de login" ON public.admin_auth_audit FOR INSERT WITH CHECK (true);
CREATE POLICY "Doar admin citeste jurnalul de audit" ON public.admin_auth_audit FOR SELECT TO authenticated USING (true);

-- Politici RLS pfa_settings
CREATE POLICY "Publicul citeste datele PFA" ON public.pfa_settings FOR SELECT USING (true);
CREATE POLICY "Doar admin editeaza datele PFA" ON public.pfa_settings FOR UPDATE TO authenticated USING (true);
`;
}
