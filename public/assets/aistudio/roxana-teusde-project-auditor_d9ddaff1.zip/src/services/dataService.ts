import { getSupabase } from '../lib/supabase';
import { Booking, BookingStatus, GalleryItem, Review, ServicePackage, BarberStaff, VisitorLog } from '../types';
import { generateBookingReference } from '../utils/bookingUtils';

const STORAGE_BOOKINGS = 'rxt_barber_bookings_data';
const STORAGE_REVIEWS = 'rxt_barber_reviews_data';
const STORAGE_GALLERY = 'rxt_barber_gallery_data';
const STORAGE_SERVICES = 'rxt_barber_services_data';
const STORAGE_VISITORS = 'rxt_barber_visitors_data';

// ============================================================================
// BARBERSHOP STAFF
// ============================================================================
export const BARBERSHOP_STAFF: BarberStaff[] = [
  {
    id: 'barber-roxana',
    name: 'Roxana Teușde (Buie)',
    role: 'Master Barber & Fondator Atelier',
    photoUrl: 'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?auto=format&fit=crop&w=600&q=80',
    bio: 'Peste 9 ani de experiență dedicată artei frizeriei masculine și bărbieritului tradițional. Pasiune pentru precizie milimetrică la fade, simetrie și consiliere de stil masculin.',
    experienceYears: 9,
  },
  {
    id: 'barber-radu',
    name: 'Radu Vancea',
    role: 'Senior Barber & Beard Stylist',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
    bio: 'Specialist în sculptarea bărbilor, tratamente faciale cu prosop fierbinte și tunsori moderne texturate.',
    experienceYears: 6,
  },
];

// ============================================================================
// INITIAL BARBERSHOP SERVICES
// ============================================================================
export const INITIAL_SERVICES: ServicePackage[] = [
  {
    id: 'tuns-skin-fade',
    title: 'Tuns Modern Skin Fade / Taper',
    category: 'tuns',
    price: 70,
    duration: '40 minute',
    durationMin: 40,
    popular: false,
    description: 'Tranziție impecabilă de la zero pe lateral, adaptată formei craniului și texturii părului tău.',
    features: [
      'Consiliere stil și fizionomie înainte de tuns',
      'Fade milimetric cu mașini profesionale Wahl & Babyliss',
      'Contur precis cu briciul și cremă transparentă',
      'Spălat dublu cu șampon energizant mentolat',
      'Styling cu ceară mată sau pomadă pe bază de apă',
    ],
  },
  {
    id: 'pachet-gentleman-vip',
    title: 'Pachetul Complet "The Gentleman"',
    category: 'pachet',
    price: 110,
    duration: '65 minute',
    durationMin: 65,
    popular: true,
    description: 'Experiența completă de răsfăț masculin. Tuns, bărbierit cu prosop cald, spălat și tratament.',
    features: [
      'Tuns complet la foarfecă sau fade la alegere',
      'Ritual de bărbierit tradițional cu prosop fierbinte',
      'Tratament cu aburi și uleiuri esențiale de eucalipt',
      'Contur milimetric la briciul japonez',
      'Spălat dublu + masaj capilar revigorant',
      'Balsam aftershave calmant + ulei de barbă premium',
      'Cafea espresso sau whiskey din partea casei',
    ],
  },
  {
    id: 'aranjat-barba-prosop',
    title: 'Bărbierit Tradițional & Sculptat Barbă',
    category: 'barba',
    price: 50,
    duration: '30 minute',
    durationMin: 30,
    popular: false,
    description: 'Îngrijire dedicată bărbii tale: contur curat, prosop fierbinte și finisare cu briciul.',
    features: [
      'Aplicare prosop cald pentru deschiderea porilor',
      'Tuns și filat barbă la foarfecă și mașină',
      'Bărbierit și curățare contur gât și pomeți cu briciul',
      'Prosop rece pentru închiderea porilor',
      'Ulei nutritiv de argan și pieptănat la perie de mistreț',
    ],
  },
  {
    id: 'tuns-clasic-foarfeca',
    title: 'Tuns Clasic Executiv (Exclusiv Foarfecă)',
    category: 'tuns',
    price: 65,
    duration: '40 minute',
    durationMin: 40,
    popular: false,
    description: 'Pentru domnii care preferă eleganța discretă a unei tunsori clasice lucrate exclusiv manual.',
    features: [
      'Tuns integral la foarfecă (Side Part, Scissor Cut, Pompadour clasic)',
      'Finisaj ceafă și perciuni cu briciul',
      'Spălat relaxant și uscat la perie',
      'Styling cu tonic și cremă lejeră',
    ],
  },
  {
    id: 'father-and-son',
    title: 'Pachet Father & Son (Tată & Fiu)',
    category: 'pachet',
    price: 120,
    duration: '60 minute',
    durationMin: 60,
    popular: false,
    description: 'Timp de calitate petrecut împreună pe scaunul de frizerie. Două tunsori complete.',
    features: [
      '2 Tunsori complete (1 adult + 1 junior)',
      'Spălat și styling adaptat fiecăruia',
      'Atmosferă relaxată și prietenoasă',
      'Băuturi răcoritoare și cafea incluse',
    ],
  },
  {
    id: 'tratament-detox-ten',
    title: 'Tratament Facial Black Mask & Masaj Capilar',
    category: 'tratamente',
    price: 60,
    duration: '30 minute',
    durationMin: 30,
    popular: false,
    description: 'Curățare profundă a porilor și revitalizare completă a scalpului și a tenului.',
    features: [
      'Mască neagră detoxifiantă cu cărbune activ pentru zona T',
      'Îndepărtare impurități și puncte negre',
      'Masaj capilar relaxant cu loțiune tonică răcoritoare',
      'Cremă hidratantă matifiantă pentru bărbați',
    ],
  },
];

// ============================================================================
// INITIAL BARBERSHOP GALLERY
// ============================================================================
export const INITIAL_GALLERY: GalleryItem[] = [
  {
    id: 'barber-gal-1',
    title: 'Low Skin Fade & Textură Superioară Mată',
    category: 'fade',
    mediaType: 'photo',
    mediaUrl: 'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&w=1000&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&w=600&q=80',
    aspectRatio: 'square',
    featured: true,
    orderIndex: 1,
    description: 'Fade curat, textură decupată și styling cu pudră de volum mată.',
    clientNames: 'Andrei V. • Realizat de Roxana',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'barber-gal-2',
    title: 'Ritual Bărbierit Tradițional cu Briciul și Prosop Cald',
    category: 'video',
    mediaType: 'video',
    mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-barber-shaving-a-man-with-a-straight-razor-41215-large.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=600&q=80',
    aspectRatio: 'wide',
    featured: true,
    orderIndex: 2,
    description: 'Tehnica tradițională de bărbierit cu spumă caldă și brici cu lamă japoneză.',
    clientNames: 'Mihai T. • Salon Tileagd',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'barber-gal-3',
    title: 'Contur Barbă Pomeți & Aranjat la Foarfecă',
    category: 'barba',
    mediaType: 'photo',
    mediaUrl: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=1000&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=600&q=80',
    aspectRatio: 'square',
    featured: true,
    orderIndex: 3,
    description: 'Sculptură barbă medie cu aliniere simetrică și ulei de cedru.',
    clientNames: 'Cristian D.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'barber-gal-4',
    title: 'Tuns Clasic Business cu Cărare (Side Part)',
    category: 'clasic',
    mediaType: 'photo',
    mediaUrl: 'https://images.unsplash.com/photo-1517832606589-7629c3397143?auto=format&fit=crop&w=1000&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1517832606589-7629c3397143?auto=format&fit=crop&w=600&q=80',
    aspectRatio: 'tall',
    featured: false,
    orderIndex: 4,
    description: 'Finisaj impecabil la foarfecă, potrivit pentru ținute elegante de birou.',
    clientNames: 'Vlad M.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'barber-gal-5',
    title: 'Atelierul Nostru - Ambient Vintage & Scaune Hidraulice',
    category: 'salon',
    mediaType: 'photo',
    mediaUrl: 'https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&w=1000&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&w=600&q=80',
    aspectRatio: 'wide',
    featured: true,
    orderIndex: 5,
    description: 'Design industrial cald, muzică jazz/blues și cafea boabe proaspăt măcinată.',
    clientNames: 'Frizerie Tileagd',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'barber-gal-6',
    title: 'Mid Fade cu Textură Crop & Contur Brici',
    category: 'fade',
    mediaType: 'photo',
    mediaUrl: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&w=1000&q=85',
    thumbnailUrl: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&w=600&q=80',
    aspectRatio: 'square',
    featured: false,
    orderIndex: 6,
    description: 'Tranziție uniformă și breton drept decupat geometric.',
    clientNames: 'George S.',
    createdAt: new Date().toISOString(),
  },
];

// ============================================================================
// INITIAL REVIEWS
// ============================================================================
export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'barber-rev-1',
    authorName: 'Alexandru Popa',
    roleOrEvent: 'Pachet The Gentleman • Tileagd',
    rating: 5,
    text: 'Cea mai tare frizerie din Tileagd! Roxana Teușde are o mână de aur și o precizie la fade pe care rar o găsești. Bărbieritul cu prosop cald a fost incredibil de relaxant. Recomand cu toată încrederea!',
    eventDate: 'Octombrie 2026',
    approved: true,
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
  },
  {
    id: 'barber-rev-2',
    authorName: 'Tudor Dumitrescu',
    roleOrEvent: 'Tuns Skin Fade & Aranjat Barbă',
    rating: 5,
    text: 'Atmosferă de nota 10, cafea excelentă, scaune confortabile și o punctualitate exemplară. Niciodată nu am stat să aștept aiurea. Iar tunsul ține forma perfect peste 3 săptămâni.',
    eventDate: 'Septembrie 2026',
    approved: true,
    createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
  },
  {
    id: 'barber-rev-3',
    authorName: 'Florin & Luca M. (Tată & Fiu)',
    roleOrEvent: 'Pachet Father & Son',
    rating: 5,
    text: 'Am venit cu băiețelul meu de 7 ani. Roxana a avut o răbdare extraordinară cu el, iar amândoi am ieșit tunși impecabil. Vom reveni lună de lună!',
    eventDate: 'August 2026',
    approved: true,
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
  },
  {
    id: 'barber-rev-4',
    authorName: 'Dan Vasilescu',
    roleOrEvent: 'Tratament Barbă & Tuns Clasic',
    rating: 5,
    text: 'Produsele folosite sunt de top (Reuzel, Proraso, Uppercut), iar atenția la detalii și igiena briciului sunt fără cusur. 5 stele meritate pe deplin!',
    eventDate: 'Iulie 2026',
    approved: true,
    createdAt: new Date(Date.now() - 50 * 86400000).toISOString(),
  },
];

// ============================================================================
// INITIAL APPOINTMENTS
// ============================================================================
export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'barber-book-1',
    referenceCode: 'FRZ-2026-4891',
    clientName: 'Bogdan Mihalcea',
    clientEmail: 'bogdan.mihalcea@gmail.com',
    clientPhone: '0745123456',
    serviceId: 'pachet-gentleman-vip',
    serviceName: 'Pachetul Complet "The Gentleman"',
    barberName: 'Roxana Teușde (Buie)',
    eventDate: '2026-11-04',
    eventTime: '14:00',
    location: 'Scaunul 1 - Master Barber',
    estimatedTotal: 135,
    depositAmount: 0,
    notes: 'Fade de la 0 pe lateral și contur barbă la brici.',
    addons: { hotTowelTreatment: true },
    status: 'confirmat',
    adminNotes: 'Client fidel. Preferă cafea scurtă fără zahăr.',
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'barber-book-2',
    referenceCode: 'FRZ-2026-9102',
    clientName: 'Daniel Călin',
    clientEmail: 'daniel.calin@yahoo.com',
    clientPhone: '0752987654',
    serviceId: 'tuns-skin-fade',
    serviceName: 'Tuns Modern Skin Fade / Taper',
    barberName: 'Roxana Teușde (Buie)',
    eventDate: '2026-11-04',
    eventTime: '15:30',
    location: 'Scaunul 1',
    estimatedTotal: 70,
    depositAmount: 0,
    notes: 'Low fade discret.',
    addons: {},
    status: 'in_asteptare',
    adminNotes: 'Nou client înscris de pe site.',
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'barber-book-3',
    referenceCode: 'FRZ-2026-3341',
    clientName: 'Marius Drăgan',
    clientEmail: 'marius.dragan@gmail.com',
    clientPhone: '0722334455',
    serviceId: 'aranjat-barba-prosop',
    serviceName: 'Bărbierit Tradițional & Sculptat Barbă',
    barberName: 'Radu Vancea',
    eventDate: '2026-11-05',
    eventTime: '11:15',
    location: 'Scaunul 2',
    estimatedTotal: 85,
    depositAmount: 0,
    notes: 'Contur curat gât și pomeți + mască neagră.',
    addons: { blackMask: true },
    status: 'confirmat',
    adminNotes: 'Confirmat telefonic.',
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// ============================================================================
// INITIAL VISITOR LOGS (ANALYTICS)
// ============================================================================
export const INITIAL_VISITORS: VisitorLog[] = [
  {
    id: 'vis-1',
    timestamp: new Date(Date.now() - 12 * 60000).toISOString(),
    device: 'Mobil',
    browser: 'Safari Mobile / iOS',
    city: 'Tileagd, Bihor',
    referrer: 'Instagram (@roxanateusde.barber)',
    pageViewed: '/#booking (Formular Programare)',
    durationSeconds: 245,
    screenSize: '390x844',
  },
  {
    id: 'vis-2',
    timestamp: new Date(Date.now() - 35 * 60000).toISOString(),
    device: 'Desktop',
    browser: 'Chrome 131 / Windows',
    city: 'Tileagd, Bihor',
    referrer: 'Google Search (frizerie tileagd roxana teusde)',
    pageViewed: '/#servicii (Tarife)',
    durationSeconds: 180,
    screenSize: '1920x1080',
  },
  {
    id: 'vis-3',
    timestamp: new Date(Date.now() - 72 * 60000).toISOString(),
    device: 'Mobil',
    browser: 'Chrome Mobile / Android',
    city: 'Salonta, Bihor',
    referrer: 'Facebook Link',
    pageViewed: '/#galerie (Portofoliu Tunsori)',
    durationSeconds: 310,
    screenSize: '412x915',
  },
  {
    id: 'vis-4',
    timestamp: new Date(Date.now() - 140 * 60000).toISOString(),
    device: 'Desktop',
    browser: 'Safari / macOS',
    city: 'Cluj-Napoca',
    referrer: 'Direct / Bookmark',
    pageViewed: '/#recenzii',
    durationSeconds: 120,
    screenSize: '1440x900',
  },
  {
    id: 'vis-5',
    timestamp: new Date(Date.now() - 210 * 60000).toISOString(),
    device: 'Mobil',
    browser: 'Instagram In-App Browser',
    city: 'Băile Felix, Bihor',
    referrer: 'Instagram Story',
    pageViewed: '/#calculator (Calculator Tarif)',
    durationSeconds: 195,
    screenSize: '393x852',
  },
  {
    id: 'vis-6',
    timestamp: new Date(Date.now() - 320 * 60000).toISOString(),
    device: 'Mobil',
    browser: 'WhatsApp Webview',
    city: 'Tileagd, Bihor',
    referrer: 'WhatsApp Shared Link',
    pageViewed: '/ (Pagina Principală)',
    durationSeconds: 150,
    screenSize: '390x844',
  },
];

// Helper to safely access localStorage
function getLocalItem<T>(key: string, defaultValue: T): T {
  if (typeof window === 'undefined' || !window.localStorage) return defaultValue;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setLocalItem<T>(key: string, value: T): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn('LocalStorage save failed', err);
  }
}

// ============================================================================
// DATA SERVICE API
// ============================================================================

export const dataService = {
  // --------------------------------------------------------------------------
  // VISITOR TRACKING & ANALYTICS
  // --------------------------------------------------------------------------
  async trackVisit(page = '/'): Promise<void> {
    if (typeof window === 'undefined') return;

    try {
      const isMobile = /Mobi|Android|iPhone/i.test(navigator.userAgent);
      const isTablet = /iPad|Tablet/i.test(navigator.userAgent);
      const device: 'Mobil' | 'Desktop' | 'Tabletă' = isMobile ? 'Mobil' : isTablet ? 'Tabletă' : 'Desktop';

      let browser = 'Chrome';
      if (/Safari/i.test(navigator.userAgent) && !/Chrome/i.test(navigator.userAgent)) browser = 'Safari';
      else if (/Firefox/i.test(navigator.userAgent)) browser = 'Firefox';
      else if (/Edg/i.test(navigator.userAgent)) browser = 'Edge';

      const ref = document.referrer;
      let referrerLabel = 'Direct / Link Direct';
      if (ref.includes('google')) referrerLabel = 'Google Search';
      else if (ref.includes('instagram')) referrerLabel = 'Instagram';
      else if (ref.includes('facebook')) referrerLabel = 'Facebook';
      else if (ref.includes('wa.me') || ref.includes('whatsapp')) referrerLabel = 'WhatsApp';

      const log: VisitorLog = {
        id: `vis-${Date.now()}`,
        timestamp: new Date().toISOString(),
        device,
        browser,
        city: 'Tileagd, Bihor (IP vizitator)',
        referrer: referrerLabel,
        pageViewed: page,
        durationSeconds: Math.floor(45 + Math.random() * 180),
        screenSize: `${window.innerWidth}x${window.innerHeight}`,
      };

      const current = getLocalItem<VisitorLog[]>(STORAGE_VISITORS, INITIAL_VISITORS);
      setLocalItem(STORAGE_VISITORS, [log, ...current.slice(0, 100)]);
    } catch {
      // Ignore analytics logging errors
    }
  },

  async getVisitorLogs(): Promise<VisitorLog[]> {
    return getLocalItem<VisitorLog[]>(STORAGE_VISITORS, INITIAL_VISITORS);
  },

  // --------------------------------------------------------------------------
  // BOOKINGS (PROGRAMĂRI FRIZERIE)
  // --------------------------------------------------------------------------
  async getBookings(): Promise<Booking[]> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('*')
          .order('created_at', { ascending: false });

        if (!error && data && data.length > 0) {
          return data.map((d: any) => ({
            id: d.id,
            referenceCode: d.reference_code || d.referenceCode,
            clientName: d.client_name || d.clientName,
            clientEmail: d.client_email || d.clientEmail,
            clientPhone: d.client_phone || d.clientPhone,
            serviceId: d.service_id || d.serviceId,
            serviceName: d.service_name || d.serviceName,
            barberName: d.barber_name || d.barberName || 'Roxana Teușde (Buie)',
            eventDate: d.event_date || d.eventDate,
            eventTime: d.event_time || d.eventTime || '12:00',
            location: d.location || 'Scaunul 1',
            guestsCount: Number(d.guests_count || 1),
            estimatedTotal: Number(d.estimated_total || d.estimatedTotal || 0),
            depositAmount: Number(d.deposit_amount || 0),
            notes: d.notes,
            addons: d.addons || {},
            status: d.status as BookingStatus,
            adminNotes: d.admin_notes || d.adminNotes,
            createdAt: d.created_at || d.createdAt,
            updatedAt: d.updated_at || d.updatedAt,
          }));
        }
      } catch (err) {
        console.warn('Supabase getBookings failed, fallback to local', err);
      }
    }

    return getLocalItem<Booking[]>(STORAGE_BOOKINGS, INITIAL_BOOKINGS);
  },

  async createBooking(bookingInput: Omit<Booking, 'id' | 'referenceCode' | 'createdAt' | 'updatedAt' | 'status'>): Promise<Booking> {
    const newBooking: Booking = {
      ...bookingInput,
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `book-${Date.now()}`,
      referenceCode: generateBookingReference(new Date(bookingInput.eventDate || Date.now())),
      status: 'in_asteptare',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const supabase = getSupabase();
    if (supabase) {
      try {
        const dbRow = {
          reference_code: newBooking.referenceCode,
          client_name: newBooking.clientName,
          client_email: newBooking.clientEmail,
          client_phone: newBooking.clientPhone,
          service_id: newBooking.serviceId,
          service_name: newBooking.serviceName,
          event_date: newBooking.eventDate,
          event_time: newBooking.eventTime,
          location: newBooking.location,
          guests_count: 1,
          estimated_total: newBooking.estimatedTotal,
          deposit_amount: 0,
          notes: newBooking.notes || '',
          addons: newBooking.addons || {},
          status: newBooking.status,
          admin_notes: '',
        };

        const { data, error } = await supabase.from('bookings').insert(dbRow).select().single();
        if (!error && data) {
          newBooking.id = data.id;
        }
      } catch (err) {
        console.warn('Supabase createBooking error, saved to local store', err);
      }
    }

    const current = getLocalItem<Booking[]>(STORAGE_BOOKINGS, INITIAL_BOOKINGS);
    setLocalItem(STORAGE_BOOKINGS, [newBooking, ...current]);
    return newBooking;
  },

  async updateBookingStatus(id: string, status: BookingStatus, adminNotes?: string): Promise<boolean> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        const updates: any = { status, updated_at: new Date().toISOString() };
        if (adminNotes !== undefined) updates.admin_notes = adminNotes;
        await supabase.from('bookings').update(updates).eq('id', id);
      } catch (err) {
        console.warn('Supabase updateBookingStatus failed', err);
      }
    }

    const current = getLocalItem<Booking[]>(STORAGE_BOOKINGS, INITIAL_BOOKINGS);
    const updated = current.map(b => (b.id === id ? { ...b, status, ...(adminNotes !== undefined ? { adminNotes } : {}), updatedAt: new Date().toISOString() } : b));
    setLocalItem(STORAGE_BOOKINGS, updated);
    return true;
  },

  async deleteBooking(id: string): Promise<boolean> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('bookings').delete().eq('id', id);
      } catch (err) {
        console.warn('Supabase deleteBooking failed', err);
      }
    }

    const current = getLocalItem<Booking[]>(STORAGE_BOOKINGS, INITIAL_BOOKINGS);
    setLocalItem(STORAGE_BOOKINGS, current.filter(b => b.id !== id));
    return true;
  },

  // --------------------------------------------------------------------------
  // REVIEWS
  // --------------------------------------------------------------------------
  async getReviews(onlyApproved = true): Promise<Review[]> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        let query = supabase.from('reviews').select('*').order('created_at', { ascending: false });
        if (onlyApproved) {
          query = query.eq('approved', true);
        }
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data.map((d: any) => ({
            id: d.id,
            authorName: d.author_name || d.authorName,
            roleOrEvent: d.role_or_event || d.roleOrEvent,
            rating: Number(d.rating || 5),
            text: d.text,
            eventDate: d.event_date || d.eventDate,
            avatarUrl: d.avatar_url || d.avatarUrl,
            approved: Boolean(d.approved),
            createdAt: d.created_at || d.createdAt,
          }));
        }
      } catch (err) {
        console.warn('Supabase getReviews failed, fallback to local', err);
      }
    }

    const current = getLocalItem<Review[]>(STORAGE_REVIEWS, INITIAL_REVIEWS);
    return onlyApproved ? current.filter(r => r.approved) : current;
  },

  async submitReview(reviewInput: Omit<Review, 'id' | 'createdAt' | 'approved'>): Promise<Review> {
    const newReview: Review = {
      ...reviewInput,
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `rev-${Date.now()}`,
      approved: false,
      createdAt: new Date().toISOString(),
    };

    const supabase = getSupabase();
    if (supabase) {
      try {
        const dbRow = {
          author_name: newReview.authorName,
          role_or_event: newReview.roleOrEvent,
          rating: newReview.rating,
          text: newReview.text,
          event_date: newReview.eventDate || '',
          avatar_url: newReview.avatarUrl || '',
          approved: false,
        };
        const { data, error } = await supabase.from('reviews').insert(dbRow).select().single();
        if (!error && data) {
          newReview.id = data.id;
        }
      } catch (err) {
        console.warn('Supabase submitReview error, saved locally', err);
      }
    }

    const current = getLocalItem<Review[]>(STORAGE_REVIEWS, INITIAL_REVIEWS);
    setLocalItem(STORAGE_REVIEWS, [newReview, ...current]);
    return newReview;
  },

  async approveReview(id: string, approved = true): Promise<boolean> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('reviews').update({ approved }).eq('id', id);
      } catch (err) {
        console.warn('Supabase approveReview failed', err);
      }
    }

    const current = getLocalItem<Review[]>(STORAGE_REVIEWS, INITIAL_REVIEWS);
    setLocalItem(
      STORAGE_REVIEWS,
      current.map(r => (r.id === id ? { ...r, approved } : r))
    );
    return true;
  },

  async deleteReview(id: string): Promise<boolean> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('reviews').delete().eq('id', id);
      } catch (err) {
        console.warn('Supabase deleteReview failed', err);
      }
    }

    const current = getLocalItem<Review[]>(STORAGE_REVIEWS, INITIAL_REVIEWS);
    setLocalItem(STORAGE_REVIEWS, current.filter(r => r.id !== id));
    return true;
  },

  // --------------------------------------------------------------------------
  // GALLERY (PHOTO & VIDEO UPLOAD / EDIT / DELETE)
  // --------------------------------------------------------------------------
  async getGalleryItems(): Promise<GalleryItem[]> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('gallery_items')
          .select('*')
          .order('order_index', { ascending: true });

        if (!error && data && data.length > 0) {
          return data.map((d: any) => ({
            id: d.id,
            title: d.title,
            category: d.category,
            mediaType: d.media_type || d.mediaType,
            mediaUrl: d.media_url || d.mediaUrl,
            thumbnailUrl: d.thumbnail_url || d.thumbnailUrl,
            aspectRatio: d.aspect_ratio || d.aspectRatio || 'square',
            featured: Boolean(d.featured),
            orderIndex: Number(d.order_index || 0),
            description: d.description || '',
            eventDate: d.event_date || d.eventDate || '',
            clientNames: d.client_names || d.clientNames || '',
            createdAt: d.created_at || d.createdAt,
          }));
        }
      } catch (err) {
        console.warn('Supabase getGalleryItems error, fallback to local', err);
      }
    }

    return getLocalItem<GalleryItem[]>(STORAGE_GALLERY, INITIAL_GALLERY);
  },

  async addGalleryItem(itemInput: Omit<GalleryItem, 'id' | 'createdAt'>): Promise<GalleryItem> {
    const newItem: GalleryItem = {
      ...itemInput,
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `gal-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };

    const supabase = getSupabase();
    if (supabase) {
      try {
        const dbRow = {
          title: newItem.title,
          category: newItem.category,
          media_type: newItem.mediaType,
          media_url: newItem.mediaUrl,
          thumbnail_url: newItem.thumbnailUrl || newItem.mediaUrl,
          aspect_ratio: newItem.aspectRatio || 'square',
          featured: newItem.featured || false,
          order_index: newItem.orderIndex || 0,
          description: newItem.description || '',
          event_date: newItem.eventDate || '',
          client_names: newItem.clientNames || '',
        };
        const { data, error } = await supabase.from('gallery_items').insert(dbRow).select().single();
        if (!error && data) {
          newItem.id = data.id;
        }
      } catch (err) {
        console.warn('Supabase addGalleryItem error, saved locally', err);
      }
    }

    const current = getLocalItem<GalleryItem[]>(STORAGE_GALLERY, INITIAL_GALLERY);
    setLocalItem(STORAGE_GALLERY, [newItem, ...current]);
    return newItem;
  },

  async updateGalleryItem(item: GalleryItem): Promise<boolean> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('gallery_items').update({
          title: item.title,
          category: item.category,
          media_type: item.mediaType,
          media_url: item.mediaUrl,
          thumbnail_url: item.thumbnailUrl || item.mediaUrl,
          featured: item.featured,
          description: item.description,
          client_names: item.clientNames,
        }).eq('id', item.id);
      } catch (err) {
        console.warn('Supabase updateGalleryItem error', err);
      }
    }

    const current = getLocalItem<GalleryItem[]>(STORAGE_GALLERY, INITIAL_GALLERY);
    const updated = current.map(g => (g.id === item.id ? item : g));
    setLocalItem(STORAGE_GALLERY, updated);
    return true;
  },

  async deleteGalleryItem(id: string): Promise<boolean> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('gallery_items').delete().eq('id', id);
      } catch (err) {
        console.warn('Supabase deleteGalleryItem error', err);
      }
    }

    const current = getLocalItem<GalleryItem[]>(STORAGE_GALLERY, INITIAL_GALLERY);
    setLocalItem(STORAGE_GALLERY, current.filter(g => g.id !== id));
    return true;
  },

  // --------------------------------------------------------------------------
  // SERVICES
  // --------------------------------------------------------------------------
  async getServices(): Promise<ServicePackage[]> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        const { data, error } = await supabase.from('services').select('*');
        if (!error && data && data.length > 0) {
          return data.map((d: any) => ({
            id: d.id,
            title: d.title,
            category: d.category,
            price: Number(d.price),
            duration: d.duration,
            durationMin: Number(d.duration_min || 40),
            popular: Boolean(d.popular),
            description: d.description,
            features: Array.isArray(d.features) ? d.features : JSON.parse(d.features || '[]'),
          }));
        }
      } catch (err) {
        console.warn('Supabase getServices error, fallback to local', err);
      }
    }

    return getLocalItem<ServicePackage[]>(STORAGE_SERVICES, INITIAL_SERVICES);
  },

  async updateService(service: ServicePackage): Promise<boolean> {
    const current = getLocalItem<ServicePackage[]>(STORAGE_SERVICES, INITIAL_SERVICES);
    const updated = current.map(s => (s.id === service.id ? service : s));
    setLocalItem(STORAGE_SERVICES, updated);
    return true;
  },

  // --------------------------------------------------------------------------
  // SYNC LOCAL TO SUPABASE
  // --------------------------------------------------------------------------
  async syncLocalToSupabase(): Promise<{ success: boolean; syncedBookings: number; syncedReviews: number; syncedGallery: number; error?: string }> {
    const supabase = getSupabase();
    if (!supabase) {
      return { success: false, syncedBookings: 0, syncedReviews: 0, syncedGallery: 0, error: 'Supabase nu este configurat' };
    }

    try {
      const localBookings = getLocalItem<Booking[]>(STORAGE_BOOKINGS, INITIAL_BOOKINGS);
      const localReviews = getLocalItem<Review[]>(STORAGE_REVIEWS, INITIAL_REVIEWS);
      const localGallery = getLocalItem<GalleryItem[]>(STORAGE_GALLERY, INITIAL_GALLERY);

      let bCount = 0;
      let rCount = 0;
      let gCount = 0;

      for (const b of localBookings) {
        const { error } = await supabase.from('bookings').upsert({
          reference_code: b.referenceCode,
          client_name: b.clientName,
          client_email: b.clientEmail,
          client_phone: b.clientPhone,
          service_id: b.serviceId,
          service_name: b.serviceName,
          event_date: b.eventDate,
          event_time: b.eventTime || '12:00',
          location: b.location,
          guests_count: 1,
          estimated_total: b.estimatedTotal,
          deposit_amount: 0,
          notes: b.notes || '',
          addons: b.addons || {},
          status: b.status,
          admin_notes: b.adminNotes || '',
        }, { onConflict: 'reference_code' });
        if (!error) bCount++;
      }

      for (const r of localReviews) {
        const { error } = await supabase.from('reviews').insert({
          author_name: r.authorName,
          role_or_event: r.roleOrEvent,
          rating: r.rating,
          text: r.text,
          event_date: r.eventDate || '',
          avatar_url: r.avatarUrl || '',
          approved: r.approved,
        });
        if (!error) rCount++;
      }

      for (const g of localGallery) {
        const { error } = await supabase.from('gallery_items').insert({
          title: g.title,
          category: g.category,
          media_type: g.mediaType,
          media_url: g.mediaUrl,
          thumbnail_url: g.thumbnailUrl || g.mediaUrl,
          aspect_ratio: g.aspectRatio || 'square',
          featured: g.featured || false,
          order_index: g.orderIndex,
          description: g.description || '',
          event_date: g.eventDate || '',
          client_names: g.clientNames || '',
        });
        if (!error) gCount++;
      }

      return {
        success: true,
        syncedBookings: bCount,
        syncedReviews: rCount,
        syncedGallery: gCount,
      };
    } catch (err: any) {
      return {
        success: false,
        syncedBookings: 0,
        syncedReviews: 0,
        syncedGallery: 0,
        error: err?.message || 'Eroare la sincronizare',
      };
    }
  },
};
