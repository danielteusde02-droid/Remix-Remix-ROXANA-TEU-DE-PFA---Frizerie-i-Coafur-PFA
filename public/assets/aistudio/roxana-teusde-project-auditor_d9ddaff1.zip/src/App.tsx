import React, { useState, useEffect } from 'react';
import { MessageSquare } from 'lucide-react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { InteractiveCalculator } from './components/InteractiveCalculator';
import { PortfolioGallery } from './components/PortfolioGallery';
import { BookingForm } from './components/BookingForm';
import { ReviewsSection } from './components/ReviewsSection';
import { GoogleMapsAgent } from './components/GoogleMapsAgent';
import { Footer } from './components/Footer';
import { AdminModal } from './components/AdminModal';
import { dataService } from './services/dataService';
import { Booking, GalleryItem, Review, ServicePackage } from './types';
import { BarbershopAddons } from './utils/bookingUtils';

export default function App() {
  const [services, setServices] = useState<ServicePackage[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  // Booking form preselection
  const [preselectedServiceId, setPreselectedServiceId] = useState<string>('tuns-skin-fade');
  const [preselectedAddons, setPreselectedAddons] = useState<BarbershopAddons>({});

  // Admin Modal
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  // Google Maps Platform quota state
  const [hasMapsQuotaExceeded, setHasMapsQuotaExceeded] = useState(false);

  // Initial load & real visitor tracking
  const refreshAllData = async () => {
    try {
      const [s, g, r] = await Promise.all([
        dataService.getServices(),
        dataService.getGalleryItems(),
        dataService.getReviews(true), // only approved reviews for public
      ]);
      setServices(s);
      setGallery(g);
      setReviews(r);
    } catch (err) {
      console.warn('Error loading initial data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshAllData();
    // Track site visit for admin analytics
    dataService.trackVisit(window.location.pathname || '/');

    const handleQuotaExceeded = () => setHasMapsQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handleQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuotaExceeded);
  }, []);

  const handleOpenBooking = () => {
    const el = document.getElementById('booking');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleExploreGallery = () => {
    const el = document.getElementById('galerie');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectPackage = (pkg: ServicePackage) => {
    setPreselectedServiceId(pkg.id);
    handleOpenBooking();
  };

  const handleApplyConfiguration = (serviceId: string, addons: BarbershopAddons) => {
    setPreselectedServiceId(serviceId);
    setPreselectedAddons(addons);
    handleOpenBooking();
  };

  return (
    <div className="min-h-screen bg-[#0c0d10] text-[#e5e5e5] flex flex-col font-sans selection:bg-[#d4af37] selection:text-zinc-950">
      {/* Google Maps Quota Notification */}
      {hasMapsQuotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* Navigation Header */}
      <Header
        onOpenBooking={handleOpenBooking}
        onOpenAdmin={() => setIsAdminOpen(true)}
        isAdminLoggedIn={isAdminLoggedIn}
      />

      {/* Main Content */}
      <main className="flex-grow">
        {/* Hero Section */}
        <Hero
          onOpenBooking={handleOpenBooking}
          onExploreGallery={handleExploreGallery}
        />

        {/* Despre Roxana Teușde (Buie) */}
        <AboutSection />

        {/* Meniu Servicii & Tarife Frizerie */}
        <ServicesSection
          services={services}
          onSelectPackage={handleSelectPackage}
        />

        {/* Configurator Personalizat */}
        <InteractiveCalculator
          services={services}
          onApplyConfiguration={handleApplyConfiguration}
        />

        {/* Portofoliu Foto & Video */}
        <PortfolioGallery items={gallery} />

        {/* Formular Programare Online */}
        <BookingForm
          services={services}
          preselectedServiceId={preselectedServiceId}
          preselectedAddons={preselectedAddons}
          onBookingCreated={() => refreshAllData()}
        />

        {/* Recenzii Clienți */}
        <ReviewsSection
          reviews={reviews}
          onReviewSubmitted={() => refreshAllData()}
        />

        {/* Asistent Traseu & Hartă Google Maps */}
        <GoogleMapsAgent />
      </main>

      {/* Footer with legal info & modals */}
      <Footer />

      {/* Admin Control Panel Modal */}
      <AdminModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        onDataModified={() => refreshAllData()}
        isAdminLoggedIn={isAdminLoggedIn}
        setIsAdminLoggedIn={setIsAdminLoggedIn}
      />

      {/* Floating WhatsApp Quick Action */}
      <a
        href="https://wa.me/40751676420?text=Salut,%20Roxana!%20Aș%20dori%20o%20programare%20la%20frizerie."
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Contactează pe WhatsApp: +40 751 676 420"
        className="fixed bottom-6 right-6 z-40 bg-emerald-600 hover:bg-emerald-500 text-white p-3.5 sm:px-4 sm:py-3 rounded-full shadow-2xl flex items-center gap-2.5 hover:scale-105 active:scale-95 transition-all border border-emerald-400/40 group cursor-pointer"
        title="Discută pe WhatsApp: +40 751 676 420"
      >
        <MessageSquare className="w-5 h-5 fill-white/20" />
        <span className="hidden sm:inline text-xs font-bold tracking-wide">
          WhatsApp • +40 751 676 420
        </span>
      </a>
    </div>
  );
}
