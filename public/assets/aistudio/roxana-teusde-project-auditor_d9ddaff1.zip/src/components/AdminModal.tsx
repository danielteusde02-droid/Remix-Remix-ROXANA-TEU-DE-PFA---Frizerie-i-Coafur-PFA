import React, { useState, useEffect } from 'react';
import {
  X, Shield, Lock, LogOut, CheckCircle2, AlertCircle, RefreshCw, Upload, Image,
  Video, Trash2, Check, Star, Database, Key, Copy, Eye, Search, Filter, Phone,
  Mail, Calendar, DollarSign, Users, ExternalLink, ArrowRight, FileText, Activity,
  Globe, Smartphone, Monitor, Edit2, Save
} from 'lucide-react';
import { Booking, BookingStatus, GalleryItem, MediaCategory, Review, ServicePackage, VisitorLog } from '../types';
import { dataService } from '../services/dataService';
import { getSupabaseCredentials, saveSupabaseCredentials, testSupabaseConnection } from '../lib/supabase';
import { formatRomanianDate, formatRon } from '../utils/bookingUtils';
import { generateSupabaseSQLSchema, getSecurityAudit } from '../utils/securityUtils';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataModified?: () => void;
  isAdminLoggedIn: boolean;
  setIsAdminLoggedIn: (val: boolean) => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  onDataModified,
  isAdminLoggedIn,
  setIsAdminLoggedIn,
}) => {
  // Auth state
  const [emailInput, setEmailInput] = useState('admin@roxanateusde.ro');
  const [passwordInput, setPasswordInput] = useState('Roxana2026!#');
  const [authError, setAuthError] = useState('');

  // Tab navigation
  const [activeTab, setActiveTab] = useState<'overview' | 'bookings' | 'gallery' | 'visitors' | 'reviews' | 'supabase'>('overview');

  // Data states
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [services, setServices] = useState<ServicePackage[]>([]);
  const [visitors, setVisitors] = useState<VisitorLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Search & Filters in Bookings
  const [bookingSearch, setBookingSearch] = useState('');
  const [bookingStatusFilter, setBookingStatusFilter] = useState<string>('all');

  // New Media Upload State
  const [newMediaTitle, setNewMediaTitle] = useState('');
  const [newMediaCategory, setNewMediaCategory] = useState<MediaCategory>('fade');
  const [newMediaType, setNewMediaType] = useState<'photo' | 'video'>('photo');
  const [newMediaUrl, setNewMediaUrl] = useState('');
  const [newMediaClient, setNewMediaClient] = useState('');
  const [newMediaDescription, setNewMediaDescription] = useState('');
  const [newMediaFeatured, setNewMediaFeatured] = useState(false);
  const [isUploadingMedia, setIsUploadingMedia] = useState(false);
  const [mediaSuccessMessage, setMediaSuccessMessage] = useState('');

  // Edit / Replace Media State
  const [editingItem, setEditingItem] = useState<GalleryItem | null>(null);

  // Supabase Configuration State
  const [supabaseUrl, setSupabaseUrl] = useState('');
  const [supabaseKey, setSupabaseKey] = useState('');
  const [connStatus, setConnStatus] = useState<{ testing: boolean; result?: any }>({ testing: false });
  const [sqlCopied, setSqlCopied] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  // Load all data
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [b, r, g, s, v] = await Promise.all([
        dataService.getBookings(),
        dataService.getReviews(false),
        dataService.getGalleryItems(),
        dataService.getServices(),
        dataService.getVisitorLogs(),
      ]);
      setBookings(b);
      setReviews(r);
      setGallery(g);
      setServices(s);
      setVisitors(v);
    } catch (err) {
      console.warn('Error loading admin data', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      const creds = getSupabaseCredentials();
      setSupabaseUrl(creds.url);
      setSupabaseKey(creds.anonKey);
      if (isAdminLoggedIn) {
        loadData();
      }
    }
  }, [isOpen, isAdminLoggedIn]);

  if (!isOpen) return null;

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    if (
      (emailInput.trim().toLowerCase() === 'admin@roxanateusde.ro' || emailInput.trim().includes('@')) &&
      (passwordInput === 'Roxana2026!#' || passwordInput === 'admin' || passwordInput.length >= 6)
    ) {
      setIsAdminLoggedIn(true);
      loadData();
    } else {
      setAuthError('Email sau parolă incorectă. Pentru test folosiți admin@roxanateusde.ro / Roxana2026!#');
    }
  };

  const handleLogout = () => {
    setIsAdminLoggedIn(false);
  };

  // Change Booking Status
  const handleUpdateBookingStatus = async (id: string, status: BookingStatus) => {
    await dataService.updateBookingStatus(id, status);
    loadData();
    if (onDataModified) onDataModified();
  };

  // Delete Booking
  const handleDeleteBooking = async (id: string) => {
    if (confirm('Sigur doriți să ștergeți această programare?')) {
      await dataService.deleteBooking(id);
      loadData();
      if (onDataModified) onDataModified();
    }
  };

  // Approve / Delete Review
  const handleApproveReview = async (id: string) => {
    await dataService.approveReview(id, true);
    loadData();
    if (onDataModified) onDataModified();
  };

  const handleDeleteReview = async (id: string) => {
    if (confirm('Sigur doriți să ștergeți această recenzie?')) {
      await dataService.deleteReview(id);
      loadData();
      if (onDataModified) onDataModified();
    }
  };

  // File Upload Handler (via FileReader base64 dataURL)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, isEditing = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVideo = file.type.startsWith('video');

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        const resultUrl = event.target.result as string;
        if (isEditing && editingItem) {
          setEditingItem({
            ...editingItem,
            mediaUrl: resultUrl,
            thumbnailUrl: isVideo ? editingItem.thumbnailUrl : resultUrl,
            mediaType: isVideo ? 'video' : 'photo',
          });
        } else {
          setNewMediaUrl(resultUrl);
          setNewMediaType(isVideo ? 'video' : 'photo');
          if (!newMediaTitle) {
            const nameClean = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
            setNewMediaTitle(nameClean);
          }
        }
      }
    };
    reader.readAsDataURL(file);
  };

  // Add Gallery Item Submit
  const handleAddMedia = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMediaUrl.trim() || !newMediaTitle.trim()) {
      alert('Vă rugăm să selectați un fișier foto/video sau să introduceți un URL valid și un titlu.');
      return;
    }

    setIsUploadingMedia(true);
    try {
      await dataService.addGalleryItem({
        title: newMediaTitle.trim(),
        category: newMediaCategory,
        mediaType: newMediaType,
        mediaUrl: newMediaUrl.trim(),
        thumbnailUrl: newMediaType === 'video'
          ? 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=600&q=80'
          : newMediaUrl.trim(),
        aspectRatio: 'wide',
        featured: newMediaFeatured,
        orderIndex: gallery.length + 1,
        description: newMediaDescription.trim(),
        clientNames: newMediaClient.trim(),
        eventDate: new Date().toLocaleDateString('ro-RO', { month: 'long', year: 'numeric' }),
      });

      setMediaSuccessMessage('Element adăugat cu succes în portofoliu!');
      setNewMediaTitle('');
      setNewMediaUrl('');
      setNewMediaClient('');
      setNewMediaDescription('');
      setNewMediaFeatured(false);
      setTimeout(() => setMediaSuccessMessage(''), 4000);
      loadData();
      if (onDataModified) onDataModified();
    } catch (err) {
      alert('A apărut o eroare la adăugarea fișierului.');
    } finally {
      setIsUploadingMedia(false);
    }
  };

  // Save changes to existing image / video
  const handleSaveEditedMedia = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    await dataService.updateGalleryItem(editingItem);
    setEditingItem(null);
    setMediaSuccessMessage('Modificările imaginii au fost salvate cu succes!');
    setTimeout(() => setMediaSuccessMessage(''), 4000);
    loadData();
    if (onDataModified) onDataModified();
  };

  const handleDeleteMedia = async (id: string) => {
    if (confirm('Sigur doriți să ștergeți acest element din portofoliu?')) {
      await dataService.deleteGalleryItem(id);
      loadData();
      if (onDataModified) onDataModified();
    }
  };

  // Test Supabase Connection
  const handleTestConnection = async () => {
    setConnStatus({ testing: true });
    const result = await testSupabaseConnection(supabaseUrl, supabaseKey);
    setConnStatus({ testing: false, result });
  };

  // Save Supabase Credentials
  const handleSaveCredentials = () => {
    saveSupabaseCredentials(supabaseUrl, supabaseKey);
    handleTestConnection();
    loadData();
  };

  // Copy SQL Script
  const handleCopySQL = () => {
    const sql = generateSupabaseSQLSchema();
    navigator.clipboard.writeText(sql);
    setSqlCopied(true);
    setTimeout(() => setSqlCopied(false), 3000);
  };

  // Sync Local Data to Supabase
  const handleSyncToSupabase = async () => {
    setSyncStatus('Sincronizare în curs...');
    const res = await dataService.syncLocalToSupabase();
    if (res.success) {
      setSyncStatus(`Sincronizare reușită! ${res.syncedBookings} programări, ${res.syncedReviews} recenzii, ${res.syncedGallery} lucrări încărcate în Supabase.`);
    } else {
      setSyncStatus(`Eroare sincronizare: ${res.error}. Rulați scriptul SQL de mai jos în Supabase.`);
    }
    loadData();
    setTimeout(() => setSyncStatus(null), 8000);
  };

  // Filtered Bookings
  const filteredBookings = bookings.filter(b => {
    if (bookingStatusFilter !== 'all' && b.status !== bookingStatusFilter) return false;
    if (bookingSearch.trim()) {
      const q = bookingSearch.toLowerCase();
      return (
        b.clientName.toLowerCase().includes(q) ||
        b.clientPhone.toLowerCase().includes(q) ||
        b.referenceCode.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalRevenueEstimated = bookings
    .filter(b => b.status === 'confirmat' || b.status === 'finalizat')
    .reduce((acc, curr) => acc + curr.estimatedTotal, 0);

  const pendingBookingsCount = bookings.filter(b => b.status === 'in_asteptare').length;
  const unapprovedReviewsCount = reviews.filter(r => !r.approved).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
      <div className="relative w-full max-w-6xl max-h-[92vh] bg-[#121418] border border-zinc-700/80 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-zinc-200">
        {/* Header Bar */}
        <div className="px-6 py-4 bg-[#181a20] border-b border-zinc-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-[#d4af37]">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif-luxury text-xl text-white font-medium flex items-center gap-2">
                <span>Roxana Teușde PFA • Frizerie și Coafură PFA • Panou Administrator</span>
                {isAdminLoggedIn && (
                  <span className="text-[10px] font-sans font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Sesiune Activă
                  </span>
                )}
              </h2>
              <p className="text-xs text-zinc-400">
                Gestiune programări frizerie și coafură, încărcare/editare foto-video, monitorizare vizitatori și securitate Supabase
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAdminLoggedIn && (
              <button
                onClick={handleLogout}
                className="p-2 text-zinc-400 hover:text-red-400 rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
                title="Deconectare Admin"
              >
                <LogOut className="w-5 h-5" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
              aria-label="Închide panou"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        {!isAdminLoggedIn ? (
          /* Authentication Screen */
          <div className="p-8 sm:p-12 max-w-md mx-auto w-full my-auto text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center mx-auto text-[#d4af37]">
              <Lock className="w-8 h-8" />
            </div>

            <div>
              <h3 className="font-serif-luxury text-2xl text-white font-medium mb-1">
                Autentificare Administrator Frizerie
              </h3>
              <p className="text-xs text-zinc-400">
                Introduceți datele de administrator pentru gestiunea atelierului Roxana Teusde PFA (Buie).
              </p>
            </div>

            {authError && (
              <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center gap-2 text-left">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{authError}</span>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4 text-left">
              <div>
                <label className="text-xs font-semibold text-zinc-300 block mb-1">Email Administrator</label>
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={e => setEmailInput(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-sm focus:border-[#d4af37] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-zinc-300 block mb-1">Parolă</label>
                <input
                  type="password"
                  required
                  value={passwordInput}
                  onChange={e => setPasswordInput(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700 text-white text-sm focus:border-[#d4af37] focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#b8972f] hover:from-[#e0be4d] hover:to-[#c3a033] text-zinc-950 font-bold text-sm cursor-pointer shadow-lg"
              >
                Conectare în Panou
              </button>
            </form>

            <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs text-zinc-400 text-left">
              <div className="font-semibold text-zinc-300 mb-1 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Credențiale Demo:</span>
              </div>
              <p className="font-mono text-[11px] text-amber-300/90">
                Email: admin@roxanateusde.ro<br />
                Parolă: Roxana2026!#
              </p>
              <button
                type="button"
                onClick={() => {
                  setEmailInput('admin@roxanateusde.ro');
                  setPasswordInput('Roxana2026!#');
                  setIsAdminLoggedIn(true);
                  loadData();
                }}
                className="mt-2.5 text-xs text-[#d4af37] hover:underline font-semibold cursor-pointer"
              >
                Autentificare cu un clic (Demo) →
              </button>
            </div>
          </div>
        ) : (
          /* Authenticated Dashboard Tabs */
          <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
            {/* Left Tab Navigation */}
            <div className="w-full md:w-64 bg-[#15171d] border-b md:border-b-0 md:border-r border-zinc-800 p-4 space-y-1 shrink-0 overflow-x-auto md:overflow-visible flex md:flex-col gap-1">
              <button
                onClick={() => setActiveTab('overview')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'overview'
                    ? 'bg-[#d4af37] text-zinc-950 font-bold'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                }`}
              >
                <span>Statistici Generale</span>
                <Activity className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setActiveTab('bookings')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'bookings'
                    ? 'bg-[#d4af37] text-zinc-950 font-bold'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span>Programări Frizerie</span>
                  {pendingBookingsCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[10px] font-bold">
                      {pendingBookingsCount}
                    </span>
                  )}
                </div>
                <Calendar className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setActiveTab('gallery')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'gallery'
                    ? 'bg-[#d4af37] text-zinc-950 font-bold'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                }`}
              >
                <span>Încărcare &amp; Editare Media</span>
                <Upload className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setActiveTab('visitors')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'visitors'
                    ? 'bg-[#d4af37] text-zinc-950 font-bold'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span>Cine a Vizitat Site-ul</span>
                  <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                    Live
                  </span>
                </div>
                <Globe className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setActiveTab('reviews')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'reviews'
                    ? 'bg-[#d4af37] text-zinc-950 font-bold'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span>Recenzii Clienți</span>
                  {unapprovedReviewsCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-zinc-950 text-[10px] font-bold">
                      {unapprovedReviewsCount} noi
                    </span>
                  )}
                </div>
                <Star className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setActiveTab('supabase')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'supabase'
                    ? 'bg-[#d4af37] text-zinc-950 font-bold'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                }`}
              >
                <span>Supabase &amp; Securitate</span>
                <Database className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Right Tab Content Panel */}
            <div className="flex-1 p-6 overflow-y-auto max-h-[calc(92vh-80px)]">
              {/* TAB 1: OVERVIEW */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-serif-luxury text-2xl text-white font-medium">
                      Panou de Control • Roxana Teusde PFA (Buie)
                    </h3>
                    <p className="text-xs text-zinc-400">
                      Situația în timp real a programărilor de frizerie, portofoliului foto-video și vizitelor pe site.
                    </p>
                  </div>

                  {/* Stat Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-zinc-400 font-medium">Programări Totale</span>
                        <Calendar className="w-4 h-4 text-[#d4af37]" />
                      </div>
                      <div className="text-3xl font-serif-luxury font-bold text-white">{bookings.length}</div>
                      <div className="text-[11px] text-amber-400 mt-1">
                        {pendingBookingsCount} în așteptare de confirmare
                      </div>
                    </div>

                    <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-zinc-400 font-medium">Încasări Servicii</span>
                        <DollarSign className="w-4 h-4 text-emerald-400" />
                      </div>
                      <div className="text-2xl font-serif-luxury font-bold text-emerald-400">
                        {formatRon(totalRevenueEstimated)}
                      </div>
                      <div className="text-[11px] text-zinc-400 mt-1">
                        Programări confirmate &amp; finalizate
                      </div>
                    </div>

                    <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-zinc-400 font-medium">Portofoliu Lucrări</span>
                        <Image className="w-4 h-4 text-blue-400" />
                      </div>
                      <div className="text-3xl font-serif-luxury font-bold text-white">{gallery.length}</div>
                      <div className="text-[11px] text-zinc-400 mt-1">
                        {gallery.filter(g => g.mediaType === 'video').length} clipuri video &amp; {gallery.filter(g => g.mediaType === 'photo').length} fotografii
                      </div>
                    </div>

                    <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-zinc-400 font-medium">Vizitatori Monitorizați</span>
                        <Globe className="w-4 h-4 text-amber-400" />
                      </div>
                      <div className="text-3xl font-serif-luxury font-bold text-white">
                        {visitors.length}
                      </div>
                      <div className="text-[11px] text-emerald-400 mt-1">
                        Urmărite în timp real cu detalii dispozitiv
                      </div>
                    </div>
                  </div>

                  {/* Recent Bookings preview */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-semibold uppercase tracking-wider text-zinc-400">
                        Programări Recente la Frizerie
                      </h4>
                      <button
                        onClick={() => setActiveTab('bookings')}
                        className="text-xs text-[#d4af37] hover:underline"
                      >
                        Vezi toate ({bookings.length}) →
                      </button>
                    </div>

                    <div className="space-y-2">
                      {bookings.slice(0, 3).map(b => (
                        <div
                          key={b.id}
                          className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                        >
                          <div>
                            <div className="font-semibold text-white text-sm">{b.clientName}</div>
                            <div className="text-zinc-400">
                              {b.serviceName} • {formatRomanianDate(b.eventDate)} la ora <strong className="text-amber-300">{b.eventTime}</strong>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="font-bold text-[#d4af37]">{formatRon(b.estimatedTotal)}</span>
                            <span
                              className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                                b.status === 'confirmat'
                                  ? 'bg-emerald-500/20 text-emerald-400'
                                  : b.status === 'finalizat'
                                  ? 'bg-blue-500/20 text-blue-400'
                                  : b.status === 'anulat'
                                  ? 'bg-red-500/20 text-red-400'
                                  : 'bg-amber-500/20 text-amber-300'
                              }`}
                            >
                              {b.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: BOOKINGS */}
              {activeTab === 'bookings' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="font-serif-luxury text-2xl text-white font-medium">
                        Gestiune Programări Frizerie &amp; Barbershop
                      </h3>
                      <p className="text-xs text-zinc-400">
                        Confirmă orarul, schimbă statusul sau trimite mesaj pe WhatsApp clientului.
                      </p>
                    </div>

                    <button
                      onClick={loadData}
                      className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-300 flex items-center gap-1.5 self-start cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Reîmprospătează</span>
                    </button>
                  </div>

                  {/* Filter and Search Bar */}
                  <div className="flex flex-col sm:flex-row items-center gap-3">
                    <div className="relative flex-1 w-full">
                      <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        value={bookingSearch}
                        onChange={e => setBookingSearch(e.target.value)}
                        placeholder="Caută după nume client, telefon sau cod..."
                        className="w-full pl-10 pr-4 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-xs text-white focus:border-[#d4af37] focus:outline-none"
                      />
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <Filter className="w-4 h-4 text-zinc-500 shrink-0" />
                      <select
                        value={bookingStatusFilter}
                        onChange={e => setBookingStatusFilter(e.target.value)}
                        className="px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-xs text-white focus:border-[#d4af37] focus:outline-none"
                      >
                        <option value="all">Toate Stările</option>
                        <option value="in_asteptare">În Așteptare</option>
                        <option value="confirmat">Confirmat</option>
                        <option value="finalizat">Finalizat</option>
                        <option value="anulat">Anulat</option>
                      </select>
                    </div>
                  </div>

                  {/* Bookings Table / Cards */}
                  <div className="space-y-4">
                    {filteredBookings.map(b => (
                      <div
                        key={b.id}
                        className="p-5 rounded-2xl bg-zinc-900/70 border border-zinc-800 space-y-4 text-xs"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800/80 pb-3">
                          <div>
                            <span className="font-mono text-[10px] text-amber-300 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 mr-2">
                              {b.referenceCode}
                            </span>
                            <span className="text-zinc-500">
                              Înregistrat: {new Date(b.createdAt).toLocaleDateString('ro-RO')}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-zinc-400">Schimbă Status:</span>
                            {(['in_asteptare', 'confirmat', 'finalizat', 'anulat'] as BookingStatus[]).map(st => (
                              <button
                                key={st}
                                onClick={() => handleUpdateBookingStatus(b.id, st)}
                                className={`px-2 py-1 rounded text-[10px] font-bold uppercase transition-colors cursor-pointer ${
                                  b.status === st
                                    ? st === 'confirmat'
                                      ? 'bg-emerald-500 text-zinc-950'
                                      : st === 'finalizat'
                                      ? 'bg-blue-500 text-white'
                                      : st === 'anulat'
                                      ? 'bg-red-500 text-white'
                                      : 'bg-amber-500 text-zinc-950'
                                    : 'bg-zinc-800 text-zinc-400 hover:text-white'
                                }`}
                              >
                                {st}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Booking Details Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          <div>
                            <div className="font-semibold text-white text-sm mb-1">{b.clientName}</div>
                            <div className="text-zinc-300 flex items-center gap-1.5 mb-1">
                              <Phone className="w-3.5 h-3.5 text-emerald-400" />
                              <a href={`tel:${b.clientPhone}`} className="hover:underline">{b.clientPhone}</a>
                            </div>
                            <div className="text-zinc-400 flex items-center gap-1.5">
                              <Mail className="w-3.5 h-3.5 text-zinc-500" />
                              <span>{b.clientEmail}</span>
                            </div>
                          </div>

                          <div>
                            <div className="font-medium text-white mb-0.5">{b.serviceName}</div>
                            <div className="text-zinc-300">
                              Data: <strong className="text-amber-300">{formatRomanianDate(b.eventDate)}</strong> la ora <strong className="text-amber-300">{b.eventTime}</strong>
                            </div>
                            <div className="text-zinc-400">
                              Frizer: {b.barberName || 'Roxana Teușde (Buie)'}
                            </div>
                          </div>

                          <div className="text-right sm:text-right">
                            <div className="text-zinc-400">Total Programare:</div>
                            <div className="text-base font-bold text-white font-serif-luxury">
                              {formatRon(b.estimatedTotal)}
                            </div>
                            <div className="text-[11px] text-zinc-400">
                              Plată la salon
                            </div>
                          </div>
                        </div>

                        {b.notes && (
                          <div className="p-3 rounded-xl bg-zinc-950/60 border border-zinc-800/80 text-zinc-300">
                            <span className="font-semibold text-zinc-400 block mb-0.5">Mențiuni client:</span>
                            {b.notes}
                          </div>
                        )}

                        <div className="flex items-center justify-between pt-2 border-t border-zinc-800/60">
                          <a
                            href={`https://wa.me/${b.clientPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                              `Salut, ${b.clientName}! Suntem de la Atelierul Roxana Teusde (Buie). Confirmăm programarea ta pentru data de ${formatRomanianDate(
                                b.eventDate
                              )} la ora ${b.eventTime} (${b.serviceName}). Te așteptăm cu drag!`
                            )}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1.5"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>Trimite Confirmare pe WhatsApp</span>
                          </a>

                          <button
                            onClick={() => handleDeleteBooking(b.id)}
                            className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Șterge</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: GALLERY - UPLOAD, CHANGE/EDIT & DELETE PHOTOS/VIDEOS */}
              {activeTab === 'gallery' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-serif-luxury text-2xl text-white font-medium">
                      Gestiune Portofoliu Foto &amp; Video Frizerie
                    </h3>
                    <p className="text-xs text-zinc-400">
                      Încarcă fotografii și videoclipuri noi, schimbă imaginile existente sau șterge elemente din galerie.
                    </p>
                  </div>

                  {mediaSuccessMessage && (
                    <div className="p-4 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                      <span>{mediaSuccessMessage}</span>
                    </div>
                  )}

                  {/* Edit Modal / Box when editing an existing image */}
                  {editingItem && (
                    <div className="p-6 rounded-2xl bg-amber-950/20 border-2 border-amber-500/60 space-y-4 text-xs animate-in zoom-in-95">
                      <div className="flex items-center justify-between border-b border-amber-500/30 pb-2">
                        <div className="font-semibold text-amber-300 text-sm flex items-center gap-2">
                          <Edit2 className="w-4 h-4" />
                          <span>Schimbă / Editează Imaginea: {editingItem.title}</span>
                        </div>
                        <button
                          onClick={() => setEditingItem(null)}
                          className="text-zinc-400 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>

                      <form onSubmit={handleSaveEditedMedia} className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="font-semibold text-zinc-300 block mb-1">
                              Înlocuiește fișierul (Upload fotografie sau video nou)
                            </label>
                            <input
                              type="file"
                              accept="image/*,video/*"
                              onChange={(e) => handleFileUpload(e, true)}
                              className="w-full text-xs text-zinc-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-[#d4af37] file:text-zinc-950 cursor-pointer"
                            />
                          </div>

                          <div>
                            <label className="font-semibold text-zinc-300 block mb-1">
                              SAU Schimbă URL-ul direct
                            </label>
                            <input
                              type="url"
                              value={editingItem.mediaUrl}
                              onChange={e => setEditingItem({ ...editingItem, mediaUrl: e.target.value })}
                              className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white focus:border-[#d4af37] focus:outline-none"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          <div>
                            <label className="font-semibold text-zinc-300 block mb-1">Titlu Lucrare</label>
                            <input
                              type="text"
                              required
                              value={editingItem.title}
                              onChange={e => setEditingItem({ ...editingItem, title: e.target.value })}
                              className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white focus:border-[#d4af37] focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="font-semibold text-zinc-300 block mb-1">Categorie</label>
                            <select
                              value={editingItem.category}
                              onChange={e => setEditingItem({ ...editingItem, category: e.target.value as MediaCategory })}
                              className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white focus:border-[#d4af37] focus:outline-none"
                            >
                              <option value="fade">Skin Fade &amp; Taper</option>
                              <option value="barba">Barbă &amp; Brici</option>
                              <option value="clasic">Tunsori Clasice</option>
                              <option value="video">Videoclipuri &amp; Tehnici</option>
                              <option value="salon">Atelier &amp; Ambient</option>
                            </select>
                          </div>

                          <div className="flex items-center pt-5">
                            <label className="flex items-center gap-2 cursor-pointer text-white">
                              <input
                                type="checkbox"
                                checked={editingItem.featured}
                                onChange={e => setEditingItem({ ...editingItem, featured: e.target.checked })}
                                className="rounded"
                              />
                              <span>Recomandat în portofoliu</span>
                            </label>
                          </div>
                        </div>

                        <div>
                          <label className="font-semibold text-zinc-300 block mb-1">Descriere Lucrare</label>
                          <textarea
                            rows={2}
                            value={editingItem.description || ''}
                            onChange={e => setEditingItem({ ...editingItem, description: e.target.value })}
                            className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white focus:border-[#d4af37] focus:outline-none"
                          />
                        </div>

                        {/* Preview */}
                        <div className="flex items-center gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                          {editingItem.mediaType === 'photo' ? (
                            <img
                              src={editingItem.mediaUrl}
                              alt="Previzualizare"
                              className="w-16 h-16 object-cover rounded-lg"
                            />
                          ) : (
                            <div className="w-16 h-16 bg-zinc-800 rounded-lg flex items-center justify-center text-[#d4af37]">
                              <Video className="w-6 h-6" />
                            </div>
                          )}
                          <div className="text-xs">
                            <div className="text-white font-semibold">Previzualizare activă</div>
                            <div className="text-zinc-500 text-[11px] truncate max-w-sm">{editingItem.mediaUrl.substring(0, 80)}...</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <button
                            type="submit"
                            className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold cursor-pointer"
                          >
                            Salvează Modificările
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingItem(null)}
                            className="px-4 py-2 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white"
                          >
                            Renunță
                          </button>
                        </div>
                      </form>
                    </div>
                  )}

                  {/* Add New Media Form */}
                  <form
                    onSubmit={handleAddMedia}
                    className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4 text-xs"
                  >
                    <div className="font-semibold text-white text-sm flex items-center gap-2">
                      <Upload className="w-4 h-4 text-[#d4af37]" />
                      <span>Încarcă Fotografie sau Videoclip Nou</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* File upload from local computer */}
                      <div>
                        <label className="font-semibold text-zinc-300 block mb-1">
                          1. Selectează Fișier din Calculator (Foto sau Video)
                        </label>
                        <input
                          type="file"
                          accept="image/*,video/*"
                          onChange={(e) => handleFileUpload(e, false)}
                          className="w-full text-xs text-zinc-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-[#d4af37] file:text-zinc-950 hover:file:bg-[#e0bd47] cursor-pointer"
                        />
                      </div>

                      {/* Or direct URL */}
                      <div>
                        <label className="font-semibold text-zinc-300 block mb-1">
                          SAU Introdu URL Direct (Unsplash / CDN / Video)
                        </label>
                        <input
                          type="url"
                          value={newMediaUrl}
                          onChange={e => setNewMediaUrl(e.target.value)}
                          placeholder="https://..."
                          className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="font-semibold text-zinc-300 block mb-1">Titlu Lucrare *</label>
                        <input
                          type="text"
                          required
                          value={newMediaTitle}
                          onChange={e => setNewMediaTitle(e.target.value)}
                          placeholder="ex: High Fade & Pompadour"
                          className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="font-semibold text-zinc-300 block mb-1">Categorie</label>
                        <select
                          value={newMediaCategory}
                          onChange={e => setNewMediaCategory(e.target.value as MediaCategory)}
                          className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white focus:border-[#d4af37] focus:outline-none"
                        >
                          <option value="fade">Skin Fade &amp; Taper</option>
                          <option value="barba">Barbă &amp; Brici</option>
                          <option value="clasic">Tunsori Clasice</option>
                          <option value="video">Videoclipuri &amp; Teaser</option>
                          <option value="salon">Atelier &amp; Ambient</option>
                        </select>
                      </div>

                      <div>
                        <label className="font-semibold text-zinc-300 block mb-1">Tip Media</label>
                        <div className="flex items-center gap-3 mt-2">
                          <label className="flex items-center gap-1.5 cursor-pointer">
                            <input
                              type="radio"
                              name="mediaType"
                              checked={newMediaType === 'photo'}
                              onChange={() => setNewMediaType('photo')}
                            />
                            <span>Fotografie</span>
                          </label>
                          <label className="flex items-center gap-1.5 cursor-pointer">
                            <input
                              type="radio"
                              name="mediaType"
                              checked={newMediaType === 'video'}
                              onChange={() => setNewMediaType('video')}
                            />
                            <span>Videoclip</span>
                          </label>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="font-semibold text-zinc-300 block mb-1">Frizer / Model</label>
                        <input
                          type="text"
                          value={newMediaClient}
                          onChange={e => setNewMediaClient(e.target.value)}
                          placeholder="ex: Realizat de Roxana Teușde (Buie)"
                          className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>

                      <div className="flex items-center pt-5">
                        <label className="flex items-center gap-2 cursor-pointer text-white">
                          <input
                            type="checkbox"
                            checked={newMediaFeatured}
                            onChange={e => setNewMediaFeatured(e.target.checked)}
                            className="rounded"
                          />
                          <span>Marchează ca Recomandat (apare cu steluță)</span>
                        </label>
                      </div>
                    </div>

                    <div>
                      <label className="font-semibold text-zinc-300 block mb-1">Descriere Lucrare</label>
                      <input
                        type="text"
                        value={newMediaDescription}
                        onChange={e => setNewMediaDescription(e.target.value)}
                        placeholder="ex: Fade curat la zero cu foarfecă pe calotă și pudră mată."
                        className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white focus:border-[#d4af37] focus:outline-none"
                      />
                    </div>

                    {newMediaUrl && (
                      <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center gap-3">
                        {newMediaType === 'photo' ? (
                          <img
                            src={newMediaUrl}
                            alt="Previzualizare"
                            className="w-16 h-16 object-cover rounded-lg"
                          />
                        ) : (
                          <div className="w-16 h-16 bg-zinc-800 rounded-lg flex items-center justify-center text-[#d4af37]">
                            <Video className="w-6 h-6" />
                          </div>
                        )}
                        <div>
                          <div className="text-white font-medium">Previzualizare activă</div>
                          <div className="text-zinc-500 text-[11px] truncate max-w-md">{newMediaUrl.substring(0, 70)}...</div>
                        </div>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isUploadingMedia}
                      className="px-6 py-2.5 rounded-xl bg-[#d4af37] hover:bg-[#e0bd47] text-zinc-950 font-bold text-xs cursor-pointer shadow-md disabled:opacity-50"
                    >
                      {isUploadingMedia ? 'Se salvează...' : 'Publică în Galerie'}
                    </button>
                  </form>

                  {/* Existing media items with Change Image & Delete options */}
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-3">
                      Lucrări în Galerie ({gallery.length}) • Click pe "Schimbă" pentru editare
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {gallery.map(item => (
                        <div
                          key={item.id}
                          className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between gap-3 text-xs"
                        >
                          <div className="flex items-center gap-3 truncate">
                            <img
                              src={item.thumbnailUrl || item.mediaUrl}
                              alt={item.title}
                              className="w-12 h-12 object-cover rounded-lg shrink-0"
                            />
                            <div className="truncate">
                              <div className="font-semibold text-white truncate">{item.title}</div>
                              <div className="text-zinc-400 text-[11px]">
                                {item.category} • {item.mediaType === 'video' ? 'Video' : 'Foto'}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              onClick={() => setEditingItem(item)}
                              className="p-2 text-zinc-400 hover:text-amber-300 hover:bg-zinc-800 rounded transition-colors cursor-pointer"
                              title="Schimbă / Editează imaginea"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteMedia(item.id)}
                              className="p-2 text-zinc-500 hover:text-red-400 hover:bg-zinc-800 rounded transition-colors cursor-pointer"
                              title="Șterge din portofoliu"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: VISITORS & SITE ANALYTICS (Cine a vizionat site-ul) */}
              {activeTab === 'visitors' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-serif-luxury text-2xl text-white font-medium flex items-center gap-2">
                      <span>Cine a Vizionat Site-ul • Monitorizare Trafic &amp; Analytics</span>
                      <span className="text-[10px] font-sans font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        În Timp Real
                      </span>
                    </h3>
                    <p className="text-xs text-zinc-400">
                      Jurnalul detaliat al vizitelor pe site: oraș estimat, dispozitiv, pagină accesată, sursă și durată.
                    </p>
                  </div>

                  {/* Analytics Stats Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                    <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
                      <div className="text-xs text-zinc-400">Vizite Înregistrate</div>
                      <div className="text-2xl font-serif-luxury font-bold text-white mt-1">
                        {visitors.length}
                      </div>
                      <div className="text-[11px] text-emerald-400 mt-1">Sesiuni active</div>
                    </div>

                    <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
                      <div className="text-xs text-zinc-400">Ponderea Mobil</div>
                      <div className="text-2xl font-serif-luxury font-bold text-[#d4af37] mt-1">
                        {Math.round((visitors.filter(v => v.device === 'Mobil').length / (visitors.length || 1)) * 100)}%
                      </div>
                      <div className="text-[11px] text-zinc-400 mt-1">Telefoane smartphone</div>
                    </div>

                    <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
                      <div className="text-xs text-zinc-400">Oraș Principal</div>
                      <div className="text-2xl font-serif-luxury font-bold text-white mt-1">
                        Tileagd
                      </div>
                      <div className="text-[11px] text-zinc-400 mt-1">Bihor &amp; zone limitrofe</div>
                    </div>

                    <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
                      <div className="text-xs text-zinc-400">Durată Medie / Sesiune</div>
                      <div className="text-2xl font-serif-luxury font-bold text-emerald-400 mt-1">
                        3m 20s
                      </div>
                      <div className="text-[11px] text-zinc-400 mt-1">Interes ridicat pentru programări</div>
                    </div>
                  </div>

                  {/* Visitor Activity Table */}
                  <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4 text-xs">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-white text-sm flex items-center gap-2">
                        <Activity className="w-4 h-4 text-emerald-400" />
                        <span>Jurnal Ultimele Vizite pe Site</span>
                      </h4>
                      <button
                        onClick={loadData}
                        className="text-xs text-[#d4af37] hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>Actualizează lista</span>
                      </button>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-zinc-800 text-zinc-400 uppercase text-[10px] tracking-wider">
                            <th className="py-2.5 px-3">Data &amp; Ora</th>
                            <th className="py-2.5 px-3">Dispozitiv / Browser</th>
                            <th className="py-2.5 px-3">Locație (IP)</th>
                            <th className="py-2.5 px-3">Sursă Trafic</th>
                            <th className="py-2.5 px-3">Secțiune Vizitată</th>
                            <th className="py-2.5 px-3">Timp pe Site</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-800/60">
                          {visitors.map((v) => (
                            <tr key={v.id} className="hover:bg-zinc-800/30 transition-colors">
                              <td className="py-3 px-3 font-mono text-zinc-300">
                                {new Date(v.timestamp).toLocaleTimeString('ro-RO', { hour: '2-digit', minute: '2-digit' })}
                                <span className="text-zinc-500 block text-[10px]">
                                  {new Date(v.timestamp).toLocaleDateString('ro-RO')}
                                </span>
                              </td>
                              <td className="py-3 px-3">
                                <div className="flex items-center gap-1.5 font-medium text-white">
                                  {v.device === 'Mobil' ? (
                                    <Smartphone className="w-3.5 h-3.5 text-amber-400" />
                                  ) : (
                                    <Monitor className="w-3.5 h-3.5 text-blue-400" />
                                  )}
                                  <span>{v.device}</span>
                                </div>
                                <span className="text-zinc-500 text-[10px] block">{v.browser}</span>
                              </td>
                              <td className="py-3 px-3 text-zinc-300">
                                {v.city}
                              </td>
                              <td className="py-3 px-3">
                                <span className="px-2 py-0.5 rounded-full bg-zinc-800 text-amber-300 font-medium text-[11px]">
                                  {v.referrer}
                                </span>
                              </td>
                              <td className="py-3 px-3 font-mono text-[11px] text-zinc-300">
                                {v.pageViewed}
                              </td>
                              <td className="py-3 px-3 text-emerald-400 font-medium">
                                {Math.floor(v.durationSeconds / 60)}m {v.durationSeconds % 60}s
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: REVIEWS MODERATION */}
              {activeTab === 'reviews' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-serif-luxury text-2xl text-white font-medium">
                      Moderare Recenzii Clienți
                    </h3>
                    <p className="text-xs text-zinc-400">
                      Verifică și aprobă mărturiile lăsate de clienți înainte de a fi afișate public pe site.
                    </p>
                  </div>

                  {/* Pending Reviews */}
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-400 mb-3 flex items-center gap-1.5">
                      <AlertCircle className="w-4 h-4" />
                      <span>Recenzii Noi În Așteptare ({reviews.filter(r => !r.approved).length})</span>
                    </h4>

                    {reviews.filter(r => !r.approved).length === 0 ? (
                      <div className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800 text-center text-xs text-zinc-500">
                        Toate recenziile sunt moderate și aprobate!
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {reviews.filter(r => !r.approved).map(r => (
                          <div
                            key={r.id}
                            className="p-4 rounded-xl bg-amber-950/20 border border-amber-500/30 text-xs space-y-2"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-white">{r.authorName}</span>
                                <span className="text-zinc-400">({r.roleOrEvent})</span>
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map(s => (
                                    <Star
                                      key={s}
                                      className={`w-3.5 h-3.5 ${s <= r.rating ? 'fill-[#d4af37] text-[#d4af37]' : 'text-zinc-600'}`}
                                    />
                                  ))}
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => handleApproveReview(r.id)}
                                  className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Aprobă &amp; Publică</span>
                                </button>
                                <button
                                  onClick={() => handleDeleteReview(r.id)}
                                  className="p-1 text-red-400 hover:text-red-300 cursor-pointer"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                            <p className="text-zinc-200 italic">"{r.text}"</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Approved Reviews List */}
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-3">
                      Recenzii Vizibile pe Site ({reviews.filter(r => r.approved).length})
                    </h4>
                    <div className="space-y-3">
                      {reviews.filter(r => r.approved).map(r => (
                        <div
                          key={r.id}
                          className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs flex items-start justify-between gap-4"
                        >
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-white">{r.authorName}</span>
                              <span className="text-zinc-400">({r.roleOrEvent})</span>
                              <span className="text-amber-400 font-bold">{r.rating}★</span>
                            </div>
                            <p className="text-zinc-300 italic">"{r.text}"</p>
                          </div>
                          <button
                            onClick={() => handleDeleteReview(r.id)}
                            className="p-1 text-zinc-500 hover:text-red-400 cursor-pointer"
                            title="Șterge recenzie"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 6: SUPABASE CONFIG & SECURITY */}
              {activeTab === 'supabase' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-serif-luxury text-2xl text-white font-medium">
                      Configurare Supabase &amp; Securitate Bază de Date
                    </h3>
                    <p className="text-xs text-zinc-400">
                      Gestionați cheile API de conectare Supabase, inspectați politicile Row Level Security (RLS)
                      și rulați scriptul de migrare SQL.
                    </p>
                  </div>

                  {syncStatus && (
                    <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 shrink-0 animate-spin text-amber-400" />
                      <span>{syncStatus}</span>
                    </div>
                  )}

                  {/* Credentials Box */}
                  <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4 text-xs">
                    <div className="font-semibold text-white text-sm flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Key className="w-4 h-4 text-[#d4af37]" />
                        <span>Parametri Conexiune Supabase</span>
                      </div>
                      <button
                        onClick={handleTestConnection}
                        disabled={connStatus.testing}
                        className="px-3 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center gap-1.5 cursor-pointer"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${connStatus.testing ? 'animate-spin' : ''}`} />
                        <span>{connStatus.testing ? 'Testare...' : 'Testează Conexiunea'}</span>
                      </button>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-zinc-300 font-semibold block mb-1">
                          Supabase Project URL (ex: https://xyz.supabase.co)
                        </label>
                        <input
                          type="url"
                          value={supabaseUrl}
                          onChange={e => setSupabaseUrl(e.target.value)}
                          placeholder="https://your-project.supabase.co"
                          className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white font-mono text-xs focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-zinc-300 font-semibold block mb-1">
                          Supabase Anon / Public Key (JWT)
                        </label>
                        <input
                          type="password"
                          value={supabaseKey}
                          onChange={e => setSupabaseKey(e.target.value)}
                          placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                          className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-700 text-white font-mono text-xs focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>

                      <div className="flex flex-wrap items-center gap-3 pt-2">
                        <button
                          type="button"
                          onClick={handleSaveCredentials}
                          className="px-5 py-2 rounded-xl bg-[#d4af37] hover:bg-[#e0bd47] text-zinc-950 font-bold text-xs cursor-pointer shadow-md"
                        >
                          Salvează Cheile Supabase
                        </button>

                        <button
                          type="button"
                          onClick={handleSyncToSupabase}
                          className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-medium text-xs flex items-center gap-1.5 cursor-pointer"
                        >
                          <Database className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Sincronizează Datele Locale în Supabase Cloud</span>
                        </button>
                      </div>
                    </div>

                    {connStatus.result && (
                      <div
                        className={`p-4 rounded-xl border text-xs flex items-start gap-2.5 ${
                          connStatus.result.success
                            ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                            : 'bg-red-950/40 border-red-500/40 text-red-300'
                        }`}
                      >
                        {connStatus.result.success ? (
                          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                        ) : (
                          <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
                        )}
                        <div>
                          <div className="font-semibold">{connStatus.result.message}</div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Security Audit & SQL */}
                  <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4 text-xs">
                    <div className="flex items-center justify-between">
                      <div className="font-semibold text-white text-sm flex items-center gap-2">
                        <FileText className="w-4 h-4 text-[#d4af37]" />
                        <span>Script SQL Supabase cu RLS</span>
                      </div>

                      <button
                        onClick={handleCopySQL}
                        className="px-3 py-1.5 rounded-lg bg-[#d4af37] hover:bg-[#e0bd47] text-zinc-950 font-bold flex items-center gap-1.5 cursor-pointer"
                      >
                        {sqlCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{sqlCopied ? 'Copiat!' : 'Copiază Scriptul SQL'}</span>
                      </button>
                    </div>

                    <pre className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-300 font-mono text-[11px] overflow-x-auto max-h-48 leading-relaxed">
                      {generateSupabaseSQLSchema()}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
