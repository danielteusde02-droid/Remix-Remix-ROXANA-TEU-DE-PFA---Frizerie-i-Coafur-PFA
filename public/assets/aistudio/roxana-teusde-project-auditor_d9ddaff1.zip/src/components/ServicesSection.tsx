import React, { useState } from 'react';
import { Check, Sparkles, Star, Calendar, ArrowRight, Clock } from 'lucide-react';
import { ServicePackage } from '../types';
import { formatRon } from '../utils/bookingUtils';

interface ServicesSectionProps {
  services: ServicePackage[];
  onSelectPackage: (pkg: ServicePackage) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ services, onSelectPackage }) => {
  const [filter, setFilter] = useState<string>('all');

  const filteredServices = services.filter(s => {
    if (filter === 'all') return true;
    return s.category === filter;
  });

  return (
    <section id="servicii" className="py-24 bg-[#0c0d10] border-b border-[#1c1f26]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/30 text-[#d4af37] text-xs font-semibold uppercase tracking-wider mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Meniu Servicii &amp; Tarife Frizerie</span>
          </div>

          <h2 className="font-serif-luxury text-3xl sm:text-5xl text-white font-normal mb-4">
            Îngrijire Masculină Fără Compromis
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg font-light leading-relaxed">
            Fiecare serviciu include spălat relaxant, produse profesionale de styling și consiliere personalizată.
          </p>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {[
              { id: 'all', label: 'Toate Serviciile' },
              { id: 'tuns', label: 'Tunsori Masculine' },
              { id: 'barba', label: 'Barbă & Bărbierit Tradițional' },
              { id: 'pachet', label: 'Pachete Complete & VIP' },
              { id: 'tratamente', label: 'Tratamente Faciale & Detox' },
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setFilter(cat.id)}
                className={`px-4 py-2 rounded-full text-xs sm:text-sm font-medium transition-all cursor-pointer ${
                  filter === cat.id
                    ? 'bg-[#d4af37] text-zinc-950 font-bold shadow-md shadow-amber-500/20'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Packages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((pkg) => (
            <div
              key={pkg.id}
              className={`relative rounded-2xl flex flex-col transition-all duration-300 ${
                pkg.popular
                  ? 'bg-gradient-to-b from-zinc-900 via-zinc-900/95 to-[#161820] border-2 border-[#d4af37] shadow-xl shadow-amber-950/20 scale-[1.02] lg:-translate-y-2'
                  : 'bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700'
              } p-6 sm:p-8`}
            >
              {/* Popular ribbon */}
              {pkg.popular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-[#d4af37] to-[#b8972f] text-zinc-950 text-xs font-bold uppercase tracking-wider py-1 px-4 rounded-full shadow-md flex items-center gap-1.5">
                  <Star className="w-3.5 h-3.5 fill-zinc-950" />
                  <span>Cel Mai Recomandat</span>
                </div>
              )}

              {/* Title & Duration */}
              <div className="mb-4">
                <span className="text-xs uppercase tracking-wider text-zinc-400 font-semibold block mb-1">
                  {pkg.category === 'tuns' ? 'Tunsoare' : pkg.category === 'barba' ? 'Îngrijire Barbă' : pkg.category === 'pachet' ? 'Pachet Special' : 'Tratament'}
                </span>
                <h3 className="font-serif-luxury text-2xl text-white font-medium">
                  {pkg.title}
                </h3>
                <div className="flex items-center gap-1.5 text-xs text-amber-400/90 mt-1.5 font-medium">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Durată: {pkg.duration}</span>
                </div>
              </div>

              {/* Price */}
              <div className="mb-6 pb-6 border-b border-zinc-800">
                <div className="flex items-baseline gap-2">
                  <span className="font-serif-luxury text-4xl sm:text-5xl font-semibold text-white">
                    {formatRon(pkg.price)}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-1">
                  Include spălat și produse de styling Reuzel / Uppercut
                </p>
              </div>

              {/* Description */}
              <p className="text-zinc-300 text-sm leading-relaxed mb-6 font-light">
                {pkg.description}
              </p>

              {/* Features list */}
              <div className="space-y-3 mb-8 grow">
                <div className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  Ce include serviciul:
                </div>
                {pkg.features.map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-zinc-300">
                    <div className="w-4 h-4 rounded-full bg-[#d4af37]/20 flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-2.5 h-2.5 text-[#d4af37]" />
                    </div>
                    <span>{feat}</span>
                  </div>
                ))}
              </div>

              {/* Button */}
              <button
                onClick={() => onSelectPackage(pkg)}
                className={`w-full py-3.5 px-6 rounded-xl font-semibold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  pkg.popular
                    ? 'bg-gradient-to-r from-[#d4af37] to-[#b8972f] hover:from-[#e2be4a] hover:to-[#c6a237] text-zinc-950 shadow-md shadow-amber-500/20'
                    : 'bg-zinc-800 hover:bg-zinc-700 text-white border border-zinc-700/80 hover:border-[#d4af37]/50'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Alege &amp; Programează-te</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
