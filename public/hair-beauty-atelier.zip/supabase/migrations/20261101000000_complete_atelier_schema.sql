-- ==============================================================================
-- MIGRARE COMPLETĂ SUPABASE: ROXANA TEUȘDE PFA (BUIE) - HAIR & BEAUTY ATELIER
-- Versiune: 20261101000000
-- Descriere: Creează și actualizează non-distructiv toate tabelele, indecșii,
--            constrângerile, bucket-ul Supabase Storage și politicile RLS.
-- ==============================================================================

-- Funcție utilitară pentru actualizarea automată a coloanei updated_at
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = timezone('utc'::text, now());
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ==============================================================================
-- 1. TABEL: public.services (Servicii & Pachete Salon)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.services (
    id VARCHAR(100) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(80) NOT NULL DEFAULT 'tuns',
    price NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (price >= 0),
    duration VARCHAR(80) NOT NULL DEFAULT '40 minute',
    duration_min INT NOT NULL DEFAULT 40 CHECK (duration_min >= 0),
    popular BOOLEAN NOT NULL DEFAULT FALSE,
    description TEXT NOT NULL DEFAULT '',
    image_url TEXT NOT NULL DEFAULT '',
    features JSONB NOT NULL DEFAULT '[]'::jsonb,
    order_index INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_services_category ON public.services(category);
CREATE INDEX IF NOT EXISTS idx_services_order ON public.services(order_index);

DROP TRIGGER IF EXISTS set_services_updated_at ON public.services;
CREATE TRIGGER set_services_updated_at
  BEFORE UPDATE ON public.services
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- ==============================================================================
-- 2. TABEL: public.service_addons (Tratamente Opționale / Servicii Extra)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.service_addons (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    price_ron NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (price_ron >= 0),
    duration_min INT NOT NULL DEFAULT 10 CHECK (duration_min >= 0),
    description TEXT NOT NULL DEFAULT '',
    image_url TEXT NOT NULL DEFAULT '',
    popular BOOLEAN NOT NULL DEFAULT FALSE,
    order_index INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_service_addons_order ON public.service_addons(order_index);

DROP TRIGGER IF EXISTS set_service_addons_updated_at ON public.service_addons;
CREATE TRIGGER set_service_addons_updated_at
  BEFORE UPDATE ON public.service_addons
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- ==============================================================================
-- 3. TABEL: public.bookings (Programări Clienți)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reference_code VARCHAR(32) NOT NULL UNIQUE,
    client_name VARCHAR(150) NOT NULL,
    client_email VARCHAR(150) NOT NULL,
    client_phone VARCHAR(50) NOT NULL,
    service_id VARCHAR(100) NOT NULL,
    service_name VARCHAR(200) NOT NULL,
    barber_name VARCHAR(100) DEFAULT 'Roxana Teușde (Buie)',
    event_date DATE NOT NULL,
    event_time VARCHAR(20) NOT NULL,
    location VARCHAR(200) DEFAULT 'Atelier Tileagd',
    guests_count INT DEFAULT 1 CHECK (guests_count >= 1),
    estimated_total NUMERIC(10, 2) DEFAULT 0 CHECK (estimated_total >= 0),
    deposit_amount NUMERIC(10, 2) DEFAULT 0 CHECK (deposit_amount >= 0),
    notes TEXT DEFAULT '',
    addons JSONB DEFAULT '{}'::jsonb,
    status VARCHAR(30) DEFAULT 'in_asteptare' CHECK (status IN ('in_asteptare', 'confirmat', 'finalizat', 'anulat')),
    admin_notes TEXT DEFAULT '',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_bookings_event_date ON public.bookings(event_date);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON public.bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_created_at ON public.bookings(created_at DESC);

DROP TRIGGER IF EXISTS set_bookings_updated_at ON public.bookings;
CREATE TRIGGER set_bookings_updated_at
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- ==============================================================================
-- 4. TABEL: public.reviews (Recenzii & Mărturii Clienți)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    author_name VARCHAR(150) NOT NULL,
    role_or_event VARCHAR(150) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    text TEXT NOT NULL,
    event_date VARCHAR(50) DEFAULT '',
    avatar_url TEXT DEFAULT '',
    approved BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_reviews_approved ON public.reviews(approved);
CREATE INDEX IF NOT EXISTS idx_reviews_created_at ON public.reviews(created_at DESC);

-- ==============================================================================
-- 5. TABEL: public.gallery_items (Portofoliu Foto & Video)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.gallery_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(200) NOT NULL,
    category VARCHAR(80) NOT NULL,
    media_type VARCHAR(20) NOT NULL CHECK (media_type IN ('photo', 'video')),
    media_url TEXT NOT NULL,
    thumbnail_url TEXT DEFAULT '',
    aspect_ratio VARCHAR(20) DEFAULT 'square',
    featured BOOLEAN DEFAULT FALSE NOT NULL,
    order_index INT DEFAULT 0 NOT NULL,
    description TEXT DEFAULT '',
    event_date VARCHAR(50) DEFAULT '',
    client_names VARCHAR(150) DEFAULT '',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.gallery_items
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL;

CREATE INDEX IF NOT EXISTS idx_gallery_category ON public.gallery_items(category);
CREATE INDEX IF NOT EXISTS idx_gallery_order ON public.gallery_items(order_index ASC);

DROP TRIGGER IF EXISTS set_gallery_items_updated_at ON public.gallery_items;
CREATE TRIGGER set_gallery_items_updated_at
  BEFORE UPDATE ON public.gallery_items
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- ==============================================================================
-- 6. TABEL: public.admin_auth_audit (Jurnal Imutabil de Securitate Admin)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.admin_auth_audit (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(150) NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('SUCCESS', 'FAILED', 'LOGOUT')),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    user_agent TEXT DEFAULT '',
    city VARCHAR(100) DEFAULT 'Tileagd, Bihor',
    failure_reason TEXT
);

CREATE INDEX IF NOT EXISTS idx_admin_auth_audit_timestamp ON public.admin_auth_audit(timestamp DESC);

-- ==============================================================================
-- 7. TABEL: public.pfa_settings (Setări Oficiale PFA, Imagini Site, Titluri & Etichete)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.pfa_settings (
    id VARCHAR(50) PRIMARY KEY DEFAULT 'current',
    brand_name VARCHAR(150) NOT NULL DEFAULT 'TEUȘDE ROXANA-LENUȚA PERSOANĂ FIZICĂ AUTORIZATĂ',
    owner_name VARCHAR(150) NOT NULL DEFAULT 'Roxana-Lenuța Teușde',
    cui VARCHAR(50) NOT NULL DEFAULT '50143520',
    reg_com VARCHAR(50) NOT NULL DEFAULT 'F2024000617057',
    registration_date VARCHAR(50) NOT NULL DEFAULT '28.05.2024',
    caen_code VARCHAR(100) NOT NULL DEFAULT '9621 · Rev. 3 — Activități de coafură și frizerie',
    address VARCHAR(200) NOT NULL DEFAULT 'Str. PLOPILOR, Nr. 28, Cod poștal 417585, Tileagd, Bihor',
    phone VARCHAR(50) NOT NULL DEFAULT '+40 751 676 420',
    email VARCHAR(100) NOT NULL DEFAULT 'contact@roxanateusde.ro',
    hours_weekday VARCHAR(100) NOT NULL DEFAULT '09:00 - 16:00',
    hours_saturday VARCHAR(100) NOT NULL DEFAULT '09:00 - 13:00',
    hours_sunday VARCHAR(50) NOT NULL DEFAULT 'Închis',
    about_bio TEXT,
    site_images JSONB DEFAULT '{"heroBgUrl":"/assets/aistudio/pt_site_ef4b9a1a.jpg","aboutPhotoUrl":"/assets/aistudio/fata_bruneta_2_60013457.jpg","salonBannerUrl":"/assets/aistudio/pt_site_ef4b9a1a.jpg"}'::jsonb,
    gallery_settings JSONB DEFAULT '{"badgeText":"Hair & Beauty Atelier","title":"Descoperă Stilul și Frumusețea alături de Roxana Teușde (Buie)","subtitle":"Fiecare stil este unic, iar fiecare transformare pune în valoare personalitatea ta. De la tunsori moderne și coafuri elegante, până la schimbări de look, culoare și styling, fiecare detaliu este realizat cu profesionalism, pasiune și atenție.","tags":[{"id":"all","label":"Toate Lucrările"},{"id":"barbati","label":"Tunsori Bărbați"},{"id":"femei","label":"Tunsori Femei"},{"id":"coafuri","label":"Coafuri"},{"id":"vopsit","label":"Vopsit & Culoare"},{"id":"styling","label":"Styling & Finisaje"},{"id":"transformari","label":"Transformări de Look"},{"id":"video","label":"Video & Inspirație"}]}'::jsonb,
    services_settings JSONB DEFAULT '{"badgeText":"Meniu Servicii & Tarife Frizerie","title":"Îngrijire Masculină Fără Compromis","subtitle":"Fiecare serviciu este realizat cu atenție, pasiune și profesionalism, folosind produse de calitate și tehnici adaptate stilului și dorințelor tale.","tags":[{"id":"all","label":"Toate Serviciile & Produsele"},{"id":"tuns","label":"Tunsori Masculine"},{"id":"barba","label":"Barbă & Bărbierit"},{"id":"pachet","label":"Pachete Complete"},{"id":"tratamente","label":"Tratamente Faciale"},{"id":"coafura","label":"Coafură Damă"},{"id":"produse","label":"Produse Styling"}]}'::jsonb,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Asigură adăugarea coloanelor noi dacă tabelul pfa_settings exista deja
ALTER TABLE public.pfa_settings
  ADD COLUMN IF NOT EXISTS site_images JSONB DEFAULT '{"heroBgUrl":"/assets/aistudio/pt_site_ef4b9a1a.jpg","aboutPhotoUrl":"/assets/aistudio/fata_bruneta_2_60013457.jpg","salonBannerUrl":"/assets/aistudio/pt_site_ef4b9a1a.jpg"}'::jsonb,
  ADD COLUMN IF NOT EXISTS gallery_settings JSONB DEFAULT '{"badgeText":"Hair & Beauty Atelier","title":"Descoperă Stilul și Frumusețea alături de Roxana Teușde (Buie)","subtitle":"Fiecare stil este unic, iar fiecare transformare pune în valoare personalitatea ta. De la tunsori moderne și coafuri elegante, până la schimbări de look, culoare și styling, fiecare detaliu este realizat cu profesionalism, pasiune și atenție.","tags":[{"id":"all","label":"Toate Lucrările"},{"id":"barbati","label":"Tunsori Bărbați"},{"id":"femei","label":"Tunsori Femei"},{"id":"coafuri","label":"Coafuri"},{"id":"vopsit","label":"Vopsit & Culoare"},{"id":"styling","label":"Styling & Finisaje"},{"id":"transformari","label":"Transformări de Look"},{"id":"video","label":"Video & Inspirație"}]}'::jsonb,
  ADD COLUMN IF NOT EXISTS services_settings JSONB DEFAULT '{"badgeText":"Meniu Servicii & Tarife Frizerie","title":"Îngrijire Masculină Fără Compromis","subtitle":"Fiecare serviciu este realizat cu atenție, pasiune și profesionalism, folosind produse de calitate și tehnici adaptate stilului și dorințelor tale.","tags":[{"id":"all","label":"Toate Serviciile & Produsele"},{"id":"tuns","label":"Tunsori Masculine"},{"id":"barba","label":"Barbă & Bărbierit"},{"id":"pachet","label":"Pachete Complete"},{"id":"tratamente","label":"Tratamente Faciale"},{"id":"coafura","label":"Coafură Damă"},{"id":"produse","label":"Produse Styling"}]}'::jsonb;

DROP TRIGGER IF EXISTS set_pfa_settings_updated_at ON public.pfa_settings;
CREATE TRIGGER set_pfa_settings_updated_at
  BEFORE UPDATE ON public.pfa_settings
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- ==============================================================================
-- 8. ACTIVARE ROW LEVEL SECURITY (RLS) PE TOATE TABELELE
-- ==============================================================================
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_addons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gallery_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_auth_audit ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pfa_settings ENABLE ROW LEVEL SECURITY;

-- Curățare politici vechi (pentru rulare idempotentă fără erori)
DROP POLICY IF EXISTS "Publicul vede serviciile" ON public.services;
DROP POLICY IF EXISTS "Doar admin adauga servicii" ON public.services;
DROP POLICY IF EXISTS "Doar admin actualizeaza servicii" ON public.services;
DROP POLICY IF EXISTS "Doar admin sterge servicii" ON public.services;

DROP POLICY IF EXISTS "Publicul vede serviciile extra" ON public.service_addons;
DROP POLICY IF EXISTS "Doar admin adauga servicii extra" ON public.service_addons;
DROP POLICY IF EXISTS "Doar admin actualizeaza servicii extra" ON public.service_addons;
DROP POLICY IF EXISTS "Doar admin sterge servicii extra" ON public.service_addons;

DROP POLICY IF EXISTS "Public pot crea programari" ON public.bookings;
DROP POLICY IF EXISTS "Doar admin citeste programarile" ON public.bookings;
DROP POLICY IF EXISTS "Doar admin actualizeaza programarile" ON public.bookings;
DROP POLICY IF EXISTS "Doar admin sterge programarile" ON public.bookings;

DROP POLICY IF EXISTS "Publicul vede recenziile aprobate" ON public.reviews;
DROP POLICY IF EXISTS "Oricine poate trimite o recenzie" ON public.reviews;
DROP POLICY IF EXISTS "Admin poate actualiza recenziile" ON public.reviews;
DROP POLICY IF EXISTS "Admin poate sterge recenziile" ON public.reviews;

DROP POLICY IF EXISTS "Publicul vede portofoliul" ON public.gallery_items;
DROP POLICY IF EXISTS "Doar admin gestioneaza galeria" ON public.gallery_items;
DROP POLICY IF EXISTS "Doar admin adauga in galerie" ON public.gallery_items;
DROP POLICY IF EXISTS "Doar admin actualizeaza galeria" ON public.gallery_items;
DROP POLICY IF EXISTS "Doar admin sterge din galerie" ON public.gallery_items;

DROP POLICY IF EXISTS "Sistemul inregistreaza incercarile de login" ON public.admin_auth_audit;
DROP POLICY IF EXISTS "Doar admin citeste jurnalul de audit" ON public.admin_auth_audit;

DROP POLICY IF EXISTS "Publicul citeste datele PFA" ON public.pfa_settings;
DROP POLICY IF EXISTS "Doar admin editeaza datele PFA" ON public.pfa_settings;
DROP POLICY IF EXISTS "Doar admin insereaza datele PFA" ON public.pfa_settings;

-- 8.1 Politici RLS: public.services
CREATE POLICY "Publicul vede serviciile"
  ON public.services FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Doar admin adauga servicii"
  ON public.services FOR INSERT
  TO authenticated
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Doar admin actualizeaza servicii"
  ON public.services FOR UPDATE
  TO authenticated
  USING (auth.role() = 'authenticated')
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Doar admin sterge servicii"
  ON public.services FOR DELETE
  TO authenticated
  USING (auth.role() = 'authenticated');

-- 8.2 Politici RLS: public.service_addons
CREATE POLICY "Publicul vede serviciile extra"
  ON public.service_addons FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Doar admin adauga servicii extra"
  ON public.service_addons FOR INSERT
  TO authenticated
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Doar admin actualizeaza servicii extra"
  ON public.service_addons FOR UPDATE
  TO authenticated
  USING (auth.role() = 'authenticated')
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Doar admin sterge servicii extra"
  ON public.service_addons FOR DELETE
  TO authenticated
  USING (auth.role() = 'authenticated');

-- 8.3 Politici RLS: public.bookings (Clienții pot doar CREA; doar Adminul autentificat vede/modifică/șterge)
CREATE POLICY "Public pot crea programari"
  ON public.bookings FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Doar admin citeste programarile"
  ON public.bookings FOR SELECT
  TO authenticated
  USING (auth.role() = 'authenticated');

CREATE POLICY "Doar admin actualizeaza programarile"
  ON public.bookings FOR UPDATE
  TO authenticated
  USING (auth.role() = 'authenticated')
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Doar admin sterge programarile"
  ON public.bookings FOR DELETE
  TO authenticated
  USING (auth.role() = 'authenticated');

-- 8.4 Politici RLS: public.reviews
CREATE POLICY "Publicul vede recenziile aprobate"
  ON public.reviews FOR SELECT
  TO anon, authenticated
  USING (approved = true OR auth.role() = 'authenticated');

CREATE POLICY "Oricine poate trimite o recenzie"
  ON public.reviews FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Admin poate actualiza recenziile"
  ON public.reviews FOR UPDATE
  TO authenticated
  USING (auth.role() = 'authenticated')
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Admin poate sterge recenziile"
  ON public.reviews FOR DELETE
  TO authenticated
  USING (auth.role() = 'authenticated');

-- 8.5 Politici RLS: public.gallery_items
CREATE POLICY "Publicul vede portofoliul"
  ON public.gallery_items FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Doar admin adauga in galerie"
  ON public.gallery_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Doar admin actualizeaza galeria"
  ON public.gallery_items FOR UPDATE
  TO authenticated
  USING (auth.role() = 'authenticated')
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Doar admin sterge din galerie"
  ON public.gallery_items FOR DELETE
  TO authenticated
  USING (auth.role() = 'authenticated');

-- 8.6 Politici RLS: public.admin_auth_audit
CREATE POLICY "Sistemul inregistreaza incercarile de login"
  ON public.admin_auth_audit FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Doar admin citeste jurnalul de audit"
  ON public.admin_auth_audit FOR SELECT
  TO authenticated
  USING (auth.role() = 'authenticated');

-- 8.7 Politici RLS: public.pfa_settings
CREATE POLICY "Publicul citeste datele PFA"
  ON public.pfa_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Doar admin insereaza datele PFA"
  ON public.pfa_settings FOR INSERT
  TO authenticated
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Doar admin editeaza datele PFA"
  ON public.pfa_settings FOR UPDATE
  TO authenticated
  USING (auth.role() = 'authenticated')
  WITH CHECK (auth.role() = 'authenticated');

-- ==============================================================================
-- 9. SUPABASE STORAGE: BUCKET 'atelier-media' & POLITICI RLS STORAGE
-- ==============================================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'atelier-media',
  'atelier-media',
  true,
  52428800,
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4', 'video/webm']
)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 52428800;

DROP POLICY IF EXISTS "Publicul poate vizualiza fisierele media" ON storage.objects;
DROP POLICY IF EXISTS "Doar admin poate incarca fisiere media" ON storage.objects;
DROP POLICY IF EXISTS "Doar admin poate actualiza fisiere media" ON storage.objects;
DROP POLICY IF EXISTS "Doar admin poate sterge fisiere media" ON storage.objects;

CREATE POLICY "Publicul poate vizualiza fisierele media"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'atelier-media');

CREATE POLICY "Doar admin poate incarca fisiere media"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'atelier-media' AND auth.role() = 'authenticated');

CREATE POLICY "Doar admin poate actualiza fisiere media"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'atelier-media' AND auth.role() = 'authenticated');

CREATE POLICY "Doar admin poate sterge fisiere media"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'atelier-media' AND auth.role() = 'authenticated');

-- ==============================================================================
-- 10. POPULARE INIȚIALĂ NON-DISTRUCTIVĂ (ON CONFLICT DO NOTHING)
-- ==============================================================================
INSERT INTO public.pfa_settings (id, brand_name, owner_name, cui, reg_com, registration_date, caen_code, address, phone, email)
VALUES (
  'current',
  'TEUȘDE ROXANA-LENUȚA PERSOANĂ FIZICĂ AUTORIZATĂ',
  'Roxana-Lenuța Teușde',
  '50143520',
  'F2024000617057',
  '28.05.2024',
  '9621 · Rev. 3 — Activități de coafură și frizerie',
  'Str. PLOPILOR, Nr. 28, Cod poștal 417585, Tileagd, Bihor',
  '+40 751 676 420',
  'contact@roxanateusde.ro'
)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.services (id, title, category, price, duration, duration_min, popular, description, image_url, features, order_index)
VALUES
  ('tuns-skin-fade', 'Tuns Modern Skin Fade / Taper', 'tuns', 70, '40 minute', 40, false, 'Tranziție impecabilă de la zero pe lateral, adaptată formei craniului și texturii părului tău.', 'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&w=800&q=80', '["Consiliere stil și fizionomie înainte de tuns","Fade milimetric cu mașini profesionale Wahl & Babyliss","Contur precis cu briciul și cremă transparentă","Spălat dublu cu șampon energizant mentolat","Styling cu ceară mată sau pomadă pe bază de apă"]'::jsonb, 1),
  ('pachet-gentleman-vip', 'Pachetul Complet "The Gentleman"', 'pachet', 110, '65 minute', 65, true, 'Experiența completă de răsfăț masculin. Tuns, bărbierit cu prosop cald, spălat și tratament.', 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=800&q=80', '["Tuns complet la foarfecă sau fade la alegere","Ritual de bărbierit tradițional cu prosop fierbinte","Tratament cu aburi și uleiuri esențiale de eucalipt","Contur milimetric la briciul japonez","Spălat dublu + masaj capilar revigorant","Balsam aftershave calmant + ulei de barbă premium","Cafea espresso sau whiskey din partea casei"]'::jsonb, 2),
  ('aranjat-barba-prosop', 'Bărbierit Tradițional & Sculptat Barbă', 'barba', 50, '30 minute', 30, false, 'Îngrijire dedicată bărbii tale: contur curat, prosop fierbinte și finisare cu briciul.', 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=800&q=80', '["Aplicare prosop cald pentru deschiderea porilor","Tuns și filat barbă la foarfecă și mașină","Bărbierit și curățare contur gât și pomeți cu briciul","Prosop rece pentru închiderea porilor","Ulei nutritiv de argan și pieptănat la perie de mistreț"]'::jsonb, 3),
  ('tuns-clasic-foarfeca', 'Tuns Clasic Executiv (Exclusiv Foarfecă)', 'tuns', 65, '40 minute', 40, false, 'Pentru domnii care preferă eleganța discretă a unei tunsori clasice lucrate exclusiv manual.', 'https://images.unsplash.com/photo-1517832606589-7629c3397143?auto=format&fit=crop&w=800&q=80', '["Tuns integral la foarfecă (Side Part, Scissor Cut, Pompadour clasic)","Finisaj ceafă și perciuni cu briciul","Spălat relaxant și uscat la perie","Styling cu tonic și cremă lejeră"]'::jsonb, 4),
  ('father-and-son', 'Pachet Father & Son (Tată & Fiu)', 'pachet', 120, '60 minute', 60, false, 'Timp de calitate petrecut împreună pe scaunul de frizerie. Două tunsori complete.', 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&w=800&q=80', '["2 Tunsori complete (1 adult + 1 junior)","Spălat și styling adaptat fiecăruia","Atmosferă relaxată și prietenoasă","Băuturi răcoritoare și cafea incluse"]'::jsonb, 5),
  ('tratament-detox-ten', 'Tratament Facial Black Mask & Masaj Capilar', 'tratamente', 60, '30 minute', 30, false, 'Curățare profundă a porilor și revitalizare completă a scalpului și a tenului.', 'https://images.unsplash.com/photo-1512290900672-1f55b9e07b8b?auto=format&fit=crop&w=800&q=80', '["Mască neagră detoxifiantă cu cărbune activ pentru zona T","Îndepărtare impurități și puncte negre","Masaj capilar relaxant cu loțiune tonică răcoritoare","Cremă hidratantă matifiantă pentru bărbați"]'::jsonb, 6),
  ('coafura-styling-dama', 'Coafură & Schimbare de Look Damă', 'coafura', 90, '50 minute', 50, false, 'Servicii de coafură dedicată pentru doamne și domnișoare: aranjat, bucle lejere sau finisaj drept impecabil.', '/assets/aistudio/fata_bruneta_2_60013457.jpg', '["Consiliere de stil și volum în funcție de fizionomie","Spălat cu șampon și mască nutritivă profesională","Uscat la perie / bucle texturate / îndreptat cu protecție termică","Fixare lejeră și ser de strălucire"]'::jsonb, 7),
  ('pudra-styling-reuzel', 'Pudră de Volum Texturantă Reuzel Matte Texture', 'produse', 65, 'Produs Salon', 0, false, 'Produs profesional de styling pentru finisaj mat și volum instant de la rădăcină. Disponibil direct în salon.', 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&q=80', '["Formulă ultra-lejeră fără senzație lipicioasă","Fixare medie și finisaj 100% mat","Ideal pentru tunsori scurte texturate și crop","Flacon 15g cu dozator de precizie"]'::jsonb, 8)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.service_addons (id, name, price_ron, duration_min, description, image_url, popular, order_index)
VALUES
  ('hotTowelTreatment', 'Tratament cu prosop cald și uleiuri esențiale', 25, 10, 'Prosop fierbinte infuzat cu ulei de eucalipt pentru relaxarea musculaturii faciale și dilatarea porilor.', 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=600&q=80', true, 1),
  ('hairWashStyling', 'Spălat dublu revitalizant + Styling profesional', 20, 10, 'Șampon mentolat răcoritor cu masaj al scalpului și coafare cu pomadă sau ceară mată.', 'https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&w=600&q=80', false, 2),
  ('blackMask', 'Mască neagră detoxifiantă cu cărbune activ (Black Mask)', 35, 15, 'Curățare profundă a punctelor negre și impurităților din zona T a feței.', 'https://images.unsplash.com/photo-1512290900672-1f02b947c617?auto=format&fit=crop&w=600&q=80', false, 3),
  ('beardCamouflage', 'Camuflaj & nuanțare fire albe barbă', 40, 15, 'Colorare semi-permanentă discretă fără tonuri roșiatice pentru un aspect uniform și masculin.', 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=600&q=80', false, 4),
  ('headMassage', 'Masaj capilar relaxant cu tonic mentolat', 30, 10, 'Stimulează circulația la rădăcina firului de păr și elimină complet tensiunea acumulată.', 'https://images.unsplash.com/photo-1517832606589-7629c3397143?auto=format&fit=crop&w=600&q=80', false, 5),
  ('eyebrowStyling', 'Stilizare & conturare sprâncene', 15, 5, 'Curățare exces și definire naturală a arcadei la brici sau pensetă.', 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&w=600&q=80', false, 6)
ON CONFLICT (id) DO NOTHING;
