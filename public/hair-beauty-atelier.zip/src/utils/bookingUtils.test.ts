import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateRomanianPhone,
  validateEmail,
  generateBookingReference,
  calculateBarberEstimate,
  AVAILABLE_TIME_SLOTS,
  getTimeSlotsForDate,
  formatRon,
  formatRomanianDate,
  formatRomanianDateWithDay,
} from './bookingUtils.js';
import {
  isValidSupabaseUrl,
  isValidSupabaseKey,
  getSecurityAudit,
  generateSupabaseSQLSchema,
} from './securityUtils.js';
import {
  hashPassword,
  verifyPassword,
  createAdminSession,
  validateAdminSession,
  authenticateAdmin,
} from './authUtils.js';
import {
  calculateDynamicRoute,
  getGoogleMapsDirectionsUrl,
  PRESET_ORIGINS,
} from './mapsUtils.js';
import { dataService } from '../services/dataService.js';

test('validateRomanianPhone correctly validates standard Romanian numbers', () => {
  assert.equal(validateRomanianPhone('0741234567'), true);
  assert.equal(validateRomanianPhone('+40741234567'), true);
  assert.equal(validateRomanianPhone('0741 234 567'), true);
  assert.equal(validateRomanianPhone('0741-234-567'), true);
  assert.equal(validateRomanianPhone('0040741234567'), true);

  // Invalid numbers
  assert.equal(validateRomanianPhone('123456'), false);
  assert.equal(validateRomanianPhone('0212345678'), false);
  assert.equal(validateRomanianPhone(''), false);
});

test('validateEmail correctly validates email addresses', () => {
  assert.equal(validateEmail('client@frizerie.ro'), true);
  assert.equal(validateEmail('alex.popa@gmail.com'), true);
  assert.equal(validateEmail('not-an-email'), false);
  assert.equal(validateEmail(''), false);
});

test('generateBookingReference produces expected FRZ prefix', () => {
  const fixedDate = new Date('2026-06-15');
  const ref = generateBookingReference(fixedDate);
  assert.match(ref, /^FRZ-2026-\d{4}$/);
});

test('calculateBarberEstimate correctly adds base haircut price, addons and extra duration', () => {
  const baseHaircutPrice = 70;
  const addons = {
    hotTowelTreatment: true,
    blackMask: true,
  };

  const result = calculateBarberEstimate(baseHaircutPrice, 40, addons);
  assert.equal(result.basePrice, 70);
  assert.equal(result.addonsTotal, 60);
  assert.equal(result.finalTotal, 130);
  assert.equal(result.totalDurationMin, 65);
});

test('AVAILABLE_TIME_SLOTS contains regular working hours (L-V 09:00 - 16:00, S 09:00 - 13:00)', () => {
  assert.ok(AVAILABLE_TIME_SLOTS.includes('09:00'));
  assert.ok(AVAILABLE_TIME_SLOTS.includes('12:00'));
  assert.ok(AVAILABLE_TIME_SLOTS.includes('15:00'));
  assert.ok(AVAILABLE_TIME_SLOTS.length >= 8);

  // Saturday check (Nov 7 2026 is a Saturday)
  const satSlots = getTimeSlotsForDate('2026-11-07');
  assert.ok(satSlots.includes('09:00'));
  assert.ok(satSlots.includes('12:30'));
  assert.equal(satSlots.includes('15:00'), false);

  // Sunday check (Nov 8 2026 is a Sunday - Closed)
  const sunSlots = getTimeSlotsForDate('2026-11-08');
  assert.equal(sunSlots.length, 0);
});

test('formatRon produces valid currency output', () => {
  const formatted = formatRon(120);
  assert.ok(formatted.includes('120'));
  assert.ok(formatted.includes('RON') || formatted.includes('lei'));
});

test('formatRomanianDate produces Romanian month names', () => {
  const formatted = formatRomanianDate('2026-08-15');
  assert.ok(formatted.includes('august'));
  assert.ok(formatted.includes('2026'));
});

test('formatRomanianDateWithDay includes weekday and Romanian month', () => {
  // 2026-11-23 is Monday
  const formatted = formatRomanianDateWithDay('2026-11-23');
  assert.ok(formatted.toLowerCase().includes('luni'));
  assert.ok(formatted.toLowerCase().includes('noiembrie'));
  assert.ok(formatted.includes('2026'));
});

test('isValidSupabaseUrl and isValidSupabaseKey accept both legacy JWT and new sb_publishable_ keys while rejecting secret keys', () => {
  assert.equal(isValidSupabaseUrl('https://xyzbarbershop.supabase.co'), true);
  assert.equal(isValidSupabaseUrl('https://example.com'), false);

  // Legacy JWT anon key
  assert.equal(
    isValidSupabaseKey('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh5eiJ9.abc123sign'),
    true
  );

  // New Supabase publishable key
  assert.equal(
    isValidSupabaseKey('sb_publishable_AbCdEfGhIjKlMnOpQrStUvWxYz123456'),
    true
  );

  // Reject secret and service_role keys
  assert.equal(isValidSupabaseKey('sb_secret_AbCdEfGhIjKlMnOpQrStUvWxYz123456'), false);
  assert.equal(isValidSupabaseKey('service_role_key_example'), false);
  assert.equal(isValidSupabaseKey('short'), false);
});

test('getSecurityAudit and generateSupabaseSQLSchema include all 7 tables, RLS policies and atelier-media storage bucket', () => {
  const audit = getSecurityAudit();
  assert.equal(audit.length, 7);
  const tables = audit.map(a => a.tableName);
  assert.ok(tables.includes('bookings'));
  assert.ok(tables.includes('services'));
  assert.ok(tables.includes('service_addons'));
  assert.ok(tables.includes('reviews'));
  assert.ok(tables.includes('gallery_items'));
  assert.ok(tables.includes('admin_auth_audit'));
  assert.ok(tables.includes('pfa_settings'));

  // Verify bookings RLS prevents public read of other clients' bookings
  const bookingsPolicy = audit.find(a => a.tableName === 'bookings');
  assert.equal(bookingsPolicy?.publicSelect, false);
  assert.equal(bookingsPolicy?.publicInsert, true);
  assert.equal(bookingsPolicy?.adminUpdate, true);
  assert.equal(bookingsPolicy?.adminDelete, true);

  const sql = generateSupabaseSQLSchema();
  assert.ok(sql.includes('CREATE TABLE IF NOT EXISTS public.services'));
  assert.ok(sql.includes('CREATE TABLE IF NOT EXISTS public.service_addons'));
  assert.ok(sql.includes('CREATE TABLE IF NOT EXISTS public.bookings'));
  assert.ok(sql.includes('CREATE TABLE IF NOT EXISTS public.reviews'));
  assert.ok(sql.includes('CREATE TABLE IF NOT EXISTS public.gallery_items'));
  assert.ok(sql.includes('CREATE TABLE IF NOT EXISTS public.admin_auth_audit'));
  assert.ok(sql.includes('CREATE TABLE IF NOT EXISTS public.pfa_settings'));
  assert.ok(sql.includes("'atelier-media'"));
});

test('hashPassword, verifyPassword, createAdminSession and authenticateAdmin work securely', async () => {
  const password = 'TestPassword2026!';
  const hash = await hashPassword(password);
  assert.ok(hash.length >= 32);

  const isValid = await verifyPassword(password, hash);
  assert.equal(isValid, true);

  const isInvalid = await verifyPassword('WrongPassword', hash);
  assert.equal(isInvalid, false);

  const session = createAdminSession('admin@roxanateusde.ro');
  assert.equal(session.username, 'admin@roxanateusde.ro');
  assert.equal(session.role, 'admin');
  assert.equal(validateAdminSession(session), true);

  const expiredSession = { ...session, expiresAt: Date.now() - 1000 };
  assert.equal(validateAdminSession(expiredSession), false);

  // Rejects wrong credentials
  const failedAuth = await authenticateAdmin('admin@roxanateusde.ro', 'parola-gresita');
  assert.equal(failedAuth.success, false);
});

test('dataService CRUD operations and empty bookings after deletion (no demo re-appearance)', async () => {
  // Mock localStorage in Node environment
  const store = new Map<string, string>();
  (globalThis as any).window = {
    localStorage: {
      getItem: (k: string) => (store.has(k) ? store.get(k)! : null),
      setItem: (k: string, v: string) => store.set(k, v),
      removeItem: (k: string) => store.delete(k),
    },
  };

  // 1. Bookings CRUD + deleting all bookings must return [] and NOT restore demo bookings
  const initialBookings = await dataService.getBookings();
  assert.ok(initialBookings.length > 0);
  for (const b of initialBookings) {
    await dataService.deleteBooking(b.id);
  }
  const afterDeleteAll = await dataService.getBookings();
  assert.equal(afterDeleteAll.length, 0, 'Deleting all bookings should not re-populate demo bookings');

  // Create new booking
  const createdBooking = await dataService.createBooking({
    clientName: 'Ionut Test',
    clientEmail: 'ionut@example.ro',
    clientPhone: '0740112233',
    serviceId: 'tuns-skin-fade',
    serviceName: 'Tuns Modern Skin Fade',
    eventDate: '2026-11-12',
    eventTime: '11:00',
    location: 'Atelier Tileagd',
    estimatedTotal: 70,
    depositAmount: 0,
  });
  assert.equal(createdBooking.clientName, 'Ionut Test');

  await dataService.updateBookingStatus(createdBooking.id, 'confirmat');
  const updatedBookings = await dataService.getBookings();
  assert.equal(updatedBookings.length, 1);
  assert.equal(updatedBookings[0].status, 'confirmat');

  // 2. Services CRUD
  const newSvc = await dataService.addService({
    title: 'Serviciu Test',
    category: 'tuns',
    price: 85,
    duration: '45 minute',
    durationMin: 45,
    popular: false,
    description: 'Descriere test',
    imageUrl: 'https://example.com/test.jpg',
    features: ['F1'],
  });
  assert.equal(newSvc.price, 85);
  await dataService.updateService({ ...newSvc, price: 95 });
  const svcsAfterUpdate = await dataService.getServices();
  assert.equal(svcsAfterUpdate.find(s => s.id === newSvc.id)?.price, 95);
  await dataService.deleteService(newSvc.id);
  const svcsAfterDelete = await dataService.getServices();
  assert.equal(svcsAfterDelete.some(s => s.id === newSvc.id), false);

  // 3. Addons CRUD
  const newAddon = await dataService.addAddon({
    name: 'Tratament Test',
    priceRon: 30,
    durationMin: 15,
    description: 'Extra',
  });
  await dataService.updateAddon({ ...newAddon, priceRon: 45 });
  const addonsAfterUpdate = await dataService.getAddons();
  assert.equal(addonsAfterUpdate.find(a => a.id === newAddon.id)?.priceRon, 45);
  await dataService.deleteAddon(newAddon.id);
  const addonsAfterDelete = await dataService.getAddons();
  assert.equal(addonsAfterDelete.some(a => a.id === newAddon.id), false);

  delete (globalThis as any).window;
});

test('mapsUtils calculates route to Str. Plopilor 28', () => {
  const preset = PRESET_ORIGINS[0];
  assert.ok(preset.distanceKm > 0);
  assert.ok(preset.durationDriveMin > 0);

  const navUrl = getGoogleMapsDirectionsUrl('Tileagd (Centru)');
  assert.ok(navUrl.includes('47.0720225') && navUrl.includes('22.1974235'));
  assert.equal(getGoogleMapsDirectionsUrl(), 'https://maps.app.goo.gl/5VWHefyfAgicsNBn6');

  const dynamic = calculateDynamicRoute('Salonta, Bihor');
  assert.ok(dynamic.distanceKm > 0);
  assert.ok(dynamic.turnByTurn.length > 0);
});
