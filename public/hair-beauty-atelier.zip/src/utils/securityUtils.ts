/**
 * Supabase Schema, Security and RLS (Row Level Security) generator
 * for ROXANA TEUSDE PFA (BUIE) database
 */

export interface SecurityPolicySummary {
  tableName: string;
  rlsEnabled: boolean;
  publicSelect: boolean;
  publicInsert: boolean;
  adminUpdate: boolean;
  adminDelete: boolean;
  description: string;
}

export function isValidSupabaseUrl(url: string): boolean {
  if (!url) return false;
  try {
    const parsed = new URL(url.trim());
    return parsed.protocol === 'https:' && parsed.hostname.includes('.supabase.co');
  } catch {
    return false;
  }
}

/**
 * Validates Supabase public / anon key.
 * Accepts both:
 * 1. New Supabase publishable keys: `sb_publishable_...`
 * 2. Legacy Supabase anon JWT keys: `eyJ...` (3 dot-separated base64url segments)
 * Explicitly rejects secret / service_role keys (`sb_secret_...`).
 */
export function isValidSupabaseKey(key: string): boolean {
  if (!key) return false;
  const trimmed = key.trim();

  // Never allow secret or service_role keys in frontend
  if (trimmed.startsWith('sb_secret_') || trimmed.includes('service_role')) {
    return false;
  }

  // New Supabase publishable key format
  if (trimmed.startsWith('sb_publishable_')) {
    return trimmed.length >= 20;
  }

  // Legacy JWT anon key format (header.payload.signature)
  const parts = trimmed.split('.');
  return parts.length === 3 && parts[0].length > 10;
}

export function getSecurityAudit(): SecurityPolicySummary[] {
  return [
    {
      tableName: 'bookings',
      rlsEnabled: true,
      publicSelect: false,
      publicInsert: true, // Clienții pot trimite programări (anon & authenticated)
      adminUpdate: true, // Doar administratorul autentificat prin Supabase Auth poate confirma/anula
      adminDelete: true, // Doar administratorul autentificat poate șterge
      description: 'Programările conțin date confidențiale (telefon, email, note). Clienții pot doar crea programări; doar administratorul autentificat le poate vizualiza sau modifica.',
    },
    {
      tableName: 'services',
      rlsEnabled: true,
      publicSelect: true, // Publicul vede lista de servicii și tarife
      publicInsert: false, // Doar administratorul autentificat poate adăuga servicii
      adminUpdate: true, // Doar administratorul autentificat poate modifica prețuri/titluri/imagini
      adminDelete: true, // Doar administratorul autentificat poate șterge servicii
      description: 'Lista oficială de servicii și pachete. Publică pentru citire, protejată prin RLS pentru adăugare, editare și ștergere.',
    },
    {
      tableName: 'service_addons',
      rlsEnabled: true,
      publicSelect: true, // Publicul vede tratamentele opționale în calculator și formular
      publicInsert: false, // Doar administratorul autentificat poate adăuga tratamente
      adminUpdate: true, // Doar administratorul autentificat poate modifica preț/timp/denumire
      adminDelete: true, // Doar administratorul autentificat poate șterge tratamente
      description: 'Tratamente opționale și servicii extra. Vizibile public, editabile exclusiv de administratorul autentificat.',
    },
    {
      tableName: 'reviews',
      rlsEnabled: true,
      publicSelect: true, // Publicul vede doar recenziile aprobate (approved = true)
      publicInsert: true, // Clienții pot trimite recenzii noi spre moderare
      adminUpdate: true, // Doar adminul poate aproba sau edita
      adminDelete: true, // Doar adminul poate șterge
      description: 'Recenziile sunt moderate. Doar recenziile cu approved = true sunt vizibile public pe site.',
    },
    {
      tableName: 'gallery_items',
      rlsEnabled: true,
      publicSelect: true, // Publicul vede fotografiile și videoclipurile
      publicInsert: false, // Doar adminul autentificat poate încărca media
      adminUpdate: true, // Doar adminul autentificat poate schimba imaginile sau titlurile
      adminDelete: true, // Doar adminul autentificat poate șterge
      description: 'Galeria foto-video este publică pentru vizualizare. Modificarea și adăugarea de conținut necesită autentificare Supabase Auth.',
    },
    {
      tableName: 'admin_auth_audit',
      rlsEnabled: true,
      publicSelect: false, // Jurnalul de securitate este strict confidențial
      publicInsert: true, // Sistemul înregistrează încercările de login
      adminUpdate: false, // Jurnal imutabil
      adminDelete: false, // Nu se șterg înregistrările de audit
      description: 'Jurnal de audit pentru toate autentificările (reușite și eșuate) ale administratorului PFA.',
    },
    {
      tableName: 'pfa_settings',
      rlsEnabled: true,
      publicSelect: true, // Datele publice PFA, imaginile de branding și titlurile secțiunilor sunt vizibile public
      publicInsert: false, // Doar adminul autentificat
      adminUpdate: true, // Doar adminul autentificat poate actualiza setările site-ului
      adminDelete: false,
      description: 'Datele de identificare PFA, imaginile principale ale site-ului, titlurile și etichetele categoriilor.',
    },
  ];
}

export function generateSupabaseSQLSchema(): string {
  return `-- ==============================================================================
-- MIGRARE COMPLETĂ SUPABASE: ROXANA TEUȘDE PFA (BUIE) - HAIR & BEAUTY ATELIER
-- Versiune: 20261101000000
-- ==============================================================================

CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = timezone('utc'::text, now());
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 1. Tabel: public.services (Servicii & Pachete Salon)
CREATE TABLE IF NOT EXISTS public.services (
    id VARCHAR(100) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(80) NOT NULL DEFAULT 'tuns',
    price NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (price >= 0),
    duration VARCHAR(80) NOT NULL DEFAULT '40 minute',
    duration_min INT NOT NULL DEFAULT 40 CHECK (duration_min >= 0),
    popular BOOLEAN NOT NULL DEFAULT FALSE,
    description TEXT NOT NULL DEFAULT '',
    image_url TEXT NOT NULL DEFAULT '',
    features JSONB NOT NULL DEFAULT '[]'::jsonb,
    order_index INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_services_category ON public.services(category);
CREATE INDEX IF NOT EXISTS idx_services_order ON public.services(order_index);

DROP TRIGGER IF EXISTS set_services_updated_at ON public.services;
CREATE TRIGGER set_services_updated_at
  BEFORE UPDATE ON public.services
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- 2. Tabel: public.service_addons (Tratamente Opționale / Servicii Extra)
CREATE TABLE IF NOT EXISTS public.service_addons (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    price_ron NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (price_ron >= 0),
    duration_min INT NOT NULL DEFAULT 10 CHECK (duration_min >= 0),
    description TEXT NOT NULL DEFAULT '',
    image_url TEXT NOT NULL DEFAULT '',
    popular BOOLEAN NOT NULL DEFAULT FALSE,
    order_index INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_service_addons_order ON public.service_addons(order_index);

DROP TRIGGER IF EXISTS set_service_addons_updated_at ON public.service_addons;
CREATE TRIGGER set_service_addons_updated_at
  BEFORE UPDATE ON public.service_addons
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- 3. Tabel: public.bookings (Programări Frizerie & Barbershop)
CREATE TABLE IF NOT EXISTS public.bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reference_code VARCHAR(32) NOT NULL UNIQUE,
    client_name VARCHAR(150) NOT NULL,
    client_email VARCHAR(150) NOT NULL,
    client_phone VARCHAR(50) NOT NULL,
    service_id VARCHAR(100) NOT NULL,
    service_name VARCHAR(200) NOT NULL,
    barber_name VARCHAR(100) DEFAULT 'Roxana Teușde (Buie)',
    event_date DATE NOT NULL,
    event_time VARCHAR(20) NOT NULL,
    location VARCHAR(200) DEFAULT 'Atelier Tileagd',
    guests_count INT DEFAULT 1 CHECK (guests_count >= 1),
    estimated_total NUMERIC(10, 2) DEFAULT 0 CHECK (estimated_total >= 0),
    deposit_amount NUMERIC(10, 2) DEFAULT 0 CHECK (deposit_amount >= 0),
    notes TEXT DEFAULT '',
    addons JSONB DEFAULT '{}'::jsonb,
    status VARCHAR(30) DEFAULT 'in_asteptare' CHECK (status IN ('in_asteptare', 'confirmat', 'finalizat', 'anulat')),
    admin_notes TEXT DEFAULT '',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_bookings_event_date ON public.bookings(event_date);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON public.bookings(status);

DROP TRIGGER IF EXISTS set_bookings_updated_at ON public.bookings;
CREATE TRIGGER set_bookings_updated_at
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- 4. Tabel: public.reviews (Recenzii & Păreri Clienți)
CREATE TABLE IF NOT EXISTS public.reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    author_name VARCHAR(150) NOT NULL,
    role_or_event VARCHAR(150) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    text TEXT NOT NULL,
    event_date VARCHAR(50) DEFAULT '',
    avatar_url TEXT DEFAULT '',
    approved BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_reviews_approved ON public.reviews(approved);

-- 5. Tabel: public.gallery_items (Portofoliu Foto & Video)
CREATE TABLE IF NOT EXISTS public.gallery_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(200) NOT NULL,
    category VARCHAR(80) NOT NULL,
    media_type VARCHAR(20) NOT NULL CHECK (media_type IN ('photo', 'video')),
    media_url TEXT NOT NULL,
    thumbnail_url TEXT DEFAULT '',
    aspect_ratio VARCHAR(20) DEFAULT 'square',
    featured BOOLEAN DEFAULT FALSE NOT NULL,
    order_index INT DEFAULT 0 NOT NULL,
    description TEXT DEFAULT '',
    event_date VARCHAR(50) DEFAULT '',
    client_names VARCHAR(150) DEFAULT '',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.gallery_items
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL;

CREATE INDEX IF NOT EXISTS idx_gallery_category ON public.gallery_items(category);
CREATE INDEX IF NOT EXISTS idx_gallery_order ON public.gallery_items(order_index ASC);

-- 6. Tabel: public.admin_auth_audit (Jurnal de Securitate Autentificări Admin)
CREATE TABLE IF NOT EXISTS public.admin_auth_audit (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(150) NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('SUCCESS', 'FAILED', 'LOGOUT')),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    user_agent TEXT DEFAULT '',
    city VARCHAR(100) DEFAULT 'Tileagd, Bihor',
    failure_reason TEXT
);

-- 7. Tabel: public.pfa_settings (Informații Oficiale PFA, Imagini Site, Titluri & Etichete)
CREATE TABLE IF NOT EXISTS public.pfa_settings (
    id VARCHAR(50) PRIMARY KEY DEFAULT 'current',
    brand_name VARCHAR(150) NOT NULL DEFAULT 'TEUȘDE ROXANA-LENUȚA PERSOANĂ FIZICĂ AUTORIZATĂ',
    owner_name VARCHAR(150) NOT NULL DEFAULT 'Roxana-Lenuța Teușde',
    cui VARCHAR(50) NOT NULL DEFAULT '50143520',
    reg_com VARCHAR(50) NOT NULL DEFAULT 'F2024000617057',
    registration_date VARCHAR(50) NOT NULL DEFAULT '28.05.2024',
    caen_code VARCHAR(100) NOT NULL DEFAULT '9621 · Rev. 3 — Activități de coafură și frizerie',
    address VARCHAR(200) NOT NULL DEFAULT 'Str. PLOPILOR, Nr. 28, Cod poștal 417585, Tileagd, Bihor',
    phone VARCHAR(50) NOT NULL DEFAULT '+40 751 676 420',
    email VARCHAR(100) NOT NULL DEFAULT 'contact@roxanateusde.ro',
    hours_weekday VARCHAR(100) NOT NULL DEFAULT '09:00 - 16:00',
    hours_saturday VARCHAR(100) NOT NULL DEFAULT '09:00 - 13:00',
    hours_sunday VARCHAR(50) NOT NULL DEFAULT 'Închis',
    about_bio TEXT,
    site_images JSONB DEFAULT '{"heroBgUrl":"/assets/aistudio/pt_site_ef4b9a1a.jpg","aboutPhotoUrl":"/assets/aistudio/fata_bruneta_2_60013457.jpg","salonBannerUrl":"/assets/aistudio/pt_site_ef4b9a1a.jpg"}'::jsonb,
    gallery_settings JSONB DEFAULT '{"badgeText":"Hair & Beauty Atelier","title":"Descoperă Stilul și Frumusețea alături de Roxana Teușde (Buie)","subtitle":"Fiecare stil este unic, iar fiecare transformare pune în valoare personalitatea ta. De la tunsori moderne și coafuri elegante, până la schimbări de look, culoare și styling, fiecare detaliu este realizat cu profesionalism, pasiune și atenție.","tags":[{"id":"all","label":"Toate Lucrările"},{"id":"barbati","label":"Tunsori Bărbați"},{"id":"femei","label":"Tunsori Femei"},{"id":"coafuri","label":"Coafuri"},{"id":"vopsit","label":"Vopsit & Culoare"},{"id":"styling","label":"Styling & Finisaje"},{"id":"transformari","label":"Transformări de Look"},{"id":"video","label":"Video & Inspirație"}]}'::jsonb,
    services_settings JSONB DEFAULT '{"badgeText":"Meniu Servicii & Tarife Frizerie","title":"Îngrijire Masculină Fără Compromis","subtitle":"Fiecare serviciu este realizat cu atenție, pasiune și profesionalism, folosind produse de calitate și tehnici adaptate stilului și dorințelor tale.","tags":[{"id":"all","label":"Toate Serviciile & Produsele"},{"id":"tuns","label":"Tunsori Masculine"},{"id":"barba","label":"Barbă & Bărbierit"},{"id":"pachet","label":"Pachete Complete"},{"id":"tratamente","label":"Tratamente Faciale"},{"id":"coafura","label":"Coafură Damă"},{"id":"produse","label":"Produse Styling"}]}'::jsonb,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.pfa_settings
  ADD COLUMN IF NOT EXISTS site_images JSONB,
  ADD COLUMN IF NOT EXISTS gallery_settings JSONB,
  ADD COLUMN IF NOT EXISTS services_settings JSONB;

-- ==============================================================================
-- ACTIVARE ROW LEVEL SECURITY (RLS)
-- ==============================================================================
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_addons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gallery_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_auth_audit ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pfa_settings ENABLE ROW LEVEL SECURITY;

-- Politici RLS services
DROP POLICY IF EXISTS "Publicul vede serviciile" ON public.services;
DROP POLICY IF EXISTS "Doar admin adauga servicii" ON public.services;
DROP POLICY IF EXISTS "Doar admin actualizeaza servicii" ON public.services;
DROP POLICY IF EXISTS "Doar admin sterge servicii" ON public.services;
CREATE POLICY "Publicul vede serviciile" ON public.services FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Doar admin adauga servicii" ON public.services FOR INSERT TO authenticated WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Doar admin actualizeaza servicii" ON public.services FOR UPDATE TO authenticated USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Doar admin sterge servicii" ON public.services FOR DELETE TO authenticated USING (auth.role() = 'authenticated');

-- Politici RLS service_addons
DROP POLICY IF EXISTS "Publicul vede serviciile extra" ON public.service_addons;
DROP POLICY IF EXISTS "Doar admin adauga servicii extra" ON public.service_addons;
DROP POLICY IF EXISTS "Doar admin actualizeaza servicii extra" ON public.service_addons;
DROP POLICY IF EXISTS "Doar admin sterge servicii extra" ON public.service_addons;
CREATE POLICY "Publicul vede serviciile extra" ON public.service_addons FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Doar admin adauga servicii extra" ON public.service_addons FOR INSERT TO authenticated WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Doar admin actualizeaza servicii extra" ON public.service_addons FOR UPDATE TO authenticated USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Doar admin sterge servicii extra" ON public.service_addons FOR DELETE TO authenticated USING (auth.role() = 'authenticated');

-- Politici RLS bookings (Clienții pot doar CREA; doar Adminul autentificat citește/actualizează/șterge)
DROP POLICY IF EXISTS "Public pot crea programari" ON public.bookings;
DROP POLICY IF EXISTS "Doar admin citeste programarile" ON public.bookings;
DROP POLICY IF EXISTS "Doar admin actualizeaza programarile" ON public.bookings;
DROP POLICY IF EXISTS "Doar admin sterge programarile" ON public.bookings;
CREATE POLICY "Public pot crea programari" ON public.bookings FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Doar admin citeste programarile" ON public.bookings FOR SELECT TO authenticated USING (auth.role() = 'authenticated');
CREATE POLICY "Doar admin actualizeaza programarile" ON public.bookings FOR UPDATE TO authenticated USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Doar admin sterge programarile" ON public.bookings FOR DELETE TO authenticated USING (auth.role() = 'authenticated');

-- Politici RLS reviews
DROP POLICY IF EXISTS "Publicul vede recenziile aprobate" ON public.reviews;
DROP POLICY IF EXISTS "Oricine poate trimite o recenzie" ON public.reviews;
DROP POLICY IF EXISTS "Admin poate actualiza recenziile" ON public.reviews;
DROP POLICY IF EXISTS "Admin poate sterge recenziile" ON public.reviews;
CREATE POLICY "Publicul vede recenziile aprobate" ON public.reviews FOR SELECT TO anon, authenticated USING (approved = true OR auth.role() = 'authenticated');
CREATE POLICY "Oricine poate trimite o recenzie" ON public.reviews FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Admin poate actualiza recenziile" ON public.reviews FOR UPDATE TO authenticated USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Admin poate sterge recenziile" ON public.reviews FOR DELETE TO authenticated USING (auth.role() = 'authenticated');

-- Politici RLS gallery_items
DROP POLICY IF EXISTS "Publicul vede portofoliul" ON public.gallery_items;
DROP POLICY IF EXISTS "Doar admin gestioneaza galeria" ON public.gallery_items;
DROP POLICY IF EXISTS "Doar admin adauga in galerie" ON public.gallery_items;
DROP POLICY IF EXISTS "Doar admin actualizeaza galeria" ON public.gallery_items;
DROP POLICY IF EXISTS "Doar admin sterge din galerie" ON public.gallery_items;
CREATE POLICY "Publicul vede portofoliul" ON public.gallery_items FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Doar admin adauga in galerie" ON public.gallery_items FOR INSERT TO authenticated WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Doar admin actualizeaza galeria" ON public.gallery_items FOR UPDATE TO authenticated USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Doar admin sterge din galerie" ON public.gallery_items FOR DELETE TO authenticated USING (auth.role() = 'authenticated');

-- Politici RLS admin_auth_audit
DROP POLICY IF EXISTS "Sistemul inregistreaza incercarile de login" ON public.admin_auth_audit;
DROP POLICY IF EXISTS "Doar admin citeste jurnalul de audit" ON public.admin_auth_audit;
CREATE POLICY "Sistemul inregistreaza incercarile de login" ON public.admin_auth_audit FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Doar admin citeste jurnalul de audit" ON public.admin_auth_audit FOR SELECT TO authenticated USING (auth.role() = 'authenticated');

-- Politici RLS pfa_settings
DROP POLICY IF EXISTS "Publicul citeste datele PFA" ON public.pfa_settings;
DROP POLICY IF EXISTS "Doar admin insereaza datele PFA" ON public.pfa_settings;
DROP POLICY IF EXISTS "Doar admin editeaza datele PFA" ON public.pfa_settings;
CREATE POLICY "Publicul citeste datele PFA" ON public.pfa_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Doar admin insereaza datele PFA" ON public.pfa_settings FOR INSERT TO authenticated WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Doar admin editeaza datele PFA" ON public.pfa_settings FOR UPDATE TO authenticated USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- ==============================================================================
-- SUPABASE STORAGE BUCKET ('atelier-media') & POLITICI ACCES
-- ==============================================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'atelier-media',
  'atelier-media',
  true,
  52428800,
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4', 'video/webm']
)
ON CONFLICT (id) DO UPDATE SET public = true, file_size_limit = 52428800;

DROP POLICY IF EXISTS "Publicul poate vizualiza fisierele media" ON storage.objects;
DROP POLICY IF EXISTS "Doar admin poate incarca fisiere media" ON storage.objects;
DROP POLICY IF EXISTS "Doar admin poate actualiza fisiere media" ON storage.objects;
DROP POLICY IF EXISTS "Doar admin poate sterge fisiere media" ON storage.objects;

CREATE POLICY "Publicul poate vizualiza fisierele media"
  ON storage.objects FOR SELECT TO anon, authenticated
  USING (bucket_id = 'atelier-media');

CREATE POLICY "Doar admin poate incarca fisiere media"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'atelier-media' AND auth.role() = 'authenticated');

CREATE POLICY "Doar admin poate actualiza fisiere media"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'atelier-media' AND auth.role() = 'authenticated');

CREATE POLICY "Doar admin poate sterge fisiere media"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'atelier-media' AND auth.role() = 'authenticated');
`;
}
