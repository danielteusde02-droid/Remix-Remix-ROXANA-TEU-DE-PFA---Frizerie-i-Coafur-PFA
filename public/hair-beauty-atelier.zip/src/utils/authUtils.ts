/**
 * Secure Authentication & Supabase Auth Integration
 * for ROXANA TEUSDE PFA (BUIE) Administrator
 */

import { getSupabase, isSupabaseConfigured } from '../lib/supabase';

export interface AdminSession {
  token: string;
  username: string;
  role: 'admin';
  authProvider: 'supabase' | 'local_fallback';
  createdAt: number;
  expiresAt: number;
}

export interface AuthAttemptLog {
  id: string;
  username: string;
  status: 'SUCCESS' | 'FAILED' | 'LOGOUT';
  timestamp: string;
  userAgent: string;
  city: string;
  failureReason?: string;
}

export const AUTH_CONFIG = {
  DEFAULT_ADMIN_USER: 'admin@roxanateusde.ro',
  SALT: 'roxana_buie_pfa_salt_2026',
  SESSION_STORAGE_KEY: 'rxt_admin_auth_session',
  AUDIT_STORAGE_KEY: 'rxt_auth_audit_logs',
  SESSION_DURATION_MS: 24 * 60 * 60 * 1000, // 24 hours
};

/**
 * Hashes a plaintext password using SHA-256 with salt via Web Crypto API or Node crypto
 */
export async function hashPassword(password: string, salt = AUTH_CONFIG.SALT): Promise<string> {
  const salted = `${password}:::${salt}`;

  if (typeof crypto !== 'undefined' && crypto.subtle && crypto.subtle.digest) {
    const encoder = new TextEncoder();
    const data = encoder.encode(salted);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  try {
    const nodeCrypto = await import('node:crypto');
    return nodeCrypto.createHash('sha256').update(salted).digest('hex');
  } catch {
    let hash = 0;
    for (let i = 0; i < salted.length; i++) {
      hash = (hash << 5) - hash + salted.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash).toString(16);
  }
}

/**
 * Verifies a plaintext password against a stored SHA-256 hash
 */
export async function verifyPassword(password: string, storedHash: string, salt = AUTH_CONFIG.SALT): Promise<boolean> {
  if (!password || !storedHash) return false;
  const computed = await hashPassword(password, salt);
  return computed.toLowerCase() === storedHash.toLowerCase();
}

/**
 * Creates an authenticated session object
 */
export function createAdminSession(
  username: string,
  authProvider: 'supabase' | 'local_fallback' = 'supabase',
  accessToken?: string
): AdminSession {
  const now = Date.now();
  const randomSuffix = Math.random().toString(36).substring(2, 15);
  return {
    token: accessToken || `rxt_sess_${now}_${randomSuffix}`,
    username: username.trim().toLowerCase(),
    role: 'admin',
    authProvider,
    createdAt: now,
    expiresAt: now + AUTH_CONFIG.SESSION_DURATION_MS,
  };
}

/**
 * Validates whether an admin session is currently active and not expired
 */
export function validateAdminSession(session: AdminSession | null | undefined): boolean {
  if (!session) return false;
  if (session.role !== 'admin') return false;
  if (!session.token || !session.username) return false;
  return Date.now() < session.expiresAt;
}

/**
 * Persists session in localStorage
 */
export function saveAdminSession(session: AdminSession): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    window.localStorage.setItem(AUTH_CONFIG.SESSION_STORAGE_KEY, JSON.stringify(session));
  } catch (err) {
    console.warn('Could not store session in localStorage', err);
  }
}

/**
 * Retrieves persisted session from storage and validates expiration
 */
export function getStoredAdminSession(): AdminSession | null {
  if (typeof window === 'undefined' || !window.localStorage) return null;
  try {
    const raw = window.localStorage.getItem(AUTH_CONFIG.SESSION_STORAGE_KEY);
    if (!raw) return null;
    const session: AdminSession = JSON.parse(raw);
    if (validateAdminSession(session)) {
      return session;
    }
    clearAdminSession();
    return null;
  } catch {
    return null;
  }
}

/**
 * Clears stored admin session
 */
export function clearAdminSession(): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    window.localStorage.removeItem(AUTH_CONFIG.SESSION_STORAGE_KEY);
  } catch (err) {
    console.warn('Could not clear session', err);
  }
}

/**
 * Checks if there is an active Supabase Auth session (or valid stored session when offline)
 */
export async function checkActiveAdminSession(): Promise<{ isLoggedIn: boolean; email?: string }> {
  const supabase = getSupabase();
  if (supabase) {
    try {
      const { data, error } = await supabase.auth.getSession();
      if (!error && data?.session?.user) {
        const email = data.session.user.email || AUTH_CONFIG.DEFAULT_ADMIN_USER;
        const sessionObj = createAdminSession(email, 'supabase', data.session.access_token);
        saveAdminSession(sessionObj);
        return { isLoggedIn: true, email };
      }
      // If Supabase is configured and has no active auth session, do not allow stale local sessions
      clearAdminSession();
      return { isLoggedIn: false };
    } catch {
      return { isLoggedIn: false };
    }
  }

  // Offline / preview environment without Supabase configured
  const localSess = getStoredAdminSession();
  if (localSess && validateAdminSession(localSess)) {
    return { isLoggedIn: true, email: localSess.username };
  }
  return { isLoggedIn: false };
}

/**
 * Authenticates the administrator via Supabase Auth (`signInWithPassword`).
 * Eliminates insecure local bypasses when Supabase is configured.
 */
export async function authenticateAdmin(
  emailOrUser: string,
  password: string
): Promise<{ success: boolean; error?: string; session?: AdminSession }> {
  const cleanInput = emailOrUser.trim().toLowerCase();
  const normalizedEmail = cleanInput.includes('@') ? cleanInput : `${cleanInput}@roxanateusde.ro`;
  const userAgent = typeof navigator !== 'undefined' ? navigator.userAgent : 'Browser';

  const supabase = getSupabase();
  if (supabase && isSupabaseConfigured()) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password: password.trim(),
      });

      if (error || !data?.session?.user) {
        await logAuthAttempt({
          username: normalizedEmail,
          status: 'FAILED',
          userAgent,
          city: 'Tileagd, Bihor',
          failureReason: error?.message || 'Supabase Auth: Date de autentificare invalide',
        });

        return {
          success: false,
          error:
            error?.message === 'Invalid login credentials'
              ? 'Email sau parolă incorectă în Supabase Auth. Verificați că utilizatorul admin este creat în Supabase Authentication -> Users.'
              : `Autentificare eșuată: ${error?.message || 'Credențiale invalide'}`,
        };
      }

      const adminSession = createAdminSession(
        data.session.user.email || normalizedEmail,
        'supabase',
        data.session.access_token
      );
      saveAdminSession(adminSession);

      await logAuthAttempt({
        username: data.session.user.email || normalizedEmail,
        status: 'SUCCESS',
        userAgent,
        city: 'Tileagd, Bihor',
      });

      return {
        success: true,
        session: adminSession,
      };
    } catch (err: any) {
      await logAuthAttempt({
        username: normalizedEmail,
        status: 'FAILED',
        userAgent,
        city: 'Tileagd, Bihor',
        failureReason: err?.message || 'Eroare rețea Supabase Auth',
      });
      return {
        success: false,
        error: `Eroare la conectarea cu Supabase Auth: ${err?.message || 'Reîncercați.'}`,
      };
    }
  }

  // Fallback ONLY when Supabase is not configured at all (local preview environment)
  const expectedHash = await hashPassword('Roxana2026!#');
  const isPassValid = await verifyPassword(password.trim(), expectedHash);
  const isUserValid =
    normalizedEmail === 'admin@roxanateusde.ro' ||
    cleanInput === 'danielteusde02@outlook.com';

  if (isUserValid && isPassValid) {
    const adminSession = createAdminSession(normalizedEmail, 'local_fallback');
    saveAdminSession(adminSession);
    await logAuthAttempt({
      username: normalizedEmail,
      status: 'SUCCESS',
      userAgent,
      city: 'Tileagd, Bihor (Mod Local)',
    });
    return {
      success: true,
      session: adminSession,
    };
  }

  await logAuthAttempt({
    username: normalizedEmail,
    status: 'FAILED',
    userAgent,
    city: 'Tileagd, Bihor',
    failureReason: 'Credențiale invalide',
  });

  return {
    success: false,
    error: 'Email sau parolă incorectă.',
  };
}

/**
 * Signs out the administrator from Supabase Auth and clears local session
 */
export async function signOutAdmin(): Promise<void> {
  const current = getStoredAdminSession();
  const supabase = getSupabase();

  if (supabase) {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.warn('Supabase signOut warning:', err);
    }
  }

  clearAdminSession();

  if (current?.username) {
    await logAuthAttempt({
      username: current.username,
      status: 'LOGOUT',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'Browser',
      city: 'Tileagd, Bihor',
    });
  }
}

/**
 * Logs an authentication attempt (SUCCESS, FAILED, LOGOUT) to Supabase and Local Storage audit table
 */
export async function logAuthAttempt(attempt: Omit<AuthAttemptLog, 'id' | 'timestamp'>): Promise<AuthAttemptLog> {
  const fullLog: AuthAttemptLog = {
    ...attempt,
    id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `auth-${Date.now()}`,
    timestamp: new Date().toISOString(),
  };

  const supabase = getSupabase();
  if (supabase) {
    try {
      await supabase.from('admin_auth_audit').insert({
        username: fullLog.username,
        status: fullLog.status,
        timestamp: fullLog.timestamp,
        user_agent: fullLog.userAgent,
        city: fullLog.city,
        failure_reason: fullLog.failureReason || null,
      });
    } catch (err) {
      console.warn('Could not write auth audit to Supabase, saving locally', err);
    }
  }

  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      const raw = window.localStorage.getItem(AUTH_CONFIG.AUDIT_STORAGE_KEY);
      const logs: AuthAttemptLog[] = raw ? JSON.parse(raw) : [];
      window.localStorage.setItem(AUTH_CONFIG.AUDIT_STORAGE_KEY, JSON.stringify([fullLog, ...logs.slice(0, 100)]));
    } catch {
      // Ignore storage write issues
    }
  }

  return fullLog;
}

/**
 * Retrieves the security audit logs from Supabase or Local Storage
 */
export async function getAuthAuditLogs(): Promise<AuthAttemptLog[]> {
  const supabase = getSupabase();
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('admin_auth_audit')
        .select('*')
        .order('timestamp', { ascending: false })
        .limit(50);

      if (!error && Array.isArray(data)) {
        return data.map((d: any) => ({
          id: d.id,
          username: d.username,
          status: d.status,
          timestamp: d.timestamp,
          userAgent: d.user_agent || d.userAgent || '',
          city: d.city || 'Tileagd, Bihor',
          failureReason: d.failure_reason || d.failureReason,
        }));
      }
    } catch {
      // Fallback
    }
  }

  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      const raw = window.localStorage.getItem(AUTH_CONFIG.AUDIT_STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch {
      // Fallback
    }
  }

  return [];
}
