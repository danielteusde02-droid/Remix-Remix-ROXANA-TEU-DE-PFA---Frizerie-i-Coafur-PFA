import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateRomanianPhone,
  validateEmail,
  generateBookingReference,
  calculateBarberEstimate,
  AVAILABLE_TIME_SLOTS,
  getTimeSlotsForDate,
  formatRon,
  formatRomanianDate,
  formatRomanianDateWithDay,
} from './bookingUtils.js';
import {
  isValidSupabaseUrl,
  isValidSupabaseKey,
  getSecurityAudit,
  generateSupabaseSQLSchema,
} from './securityUtils.js';
import {
  hashPassword,
  verifyPassword,
  createAdminSession,
  validateAdminSession,
} from './authUtils.js';
import {
  calculateDynamicRoute,
  getGoogleMapsDirectionsUrl,
  PRESET_ORIGINS,
} from './mapsUtils.js';

test('validateRomanianPhone correctly validates standard Romanian numbers', () => {
  assert.equal(validateRomanianPhone('0741234567'), true);
  assert.equal(validateRomanianPhone('+40741234567'), true);
  assert.equal(validateRomanianPhone('0741 234 567'), true);
  assert.equal(validateRomanianPhone('0741-234-567'), true);
  assert.equal(validateRomanianPhone('0040741234567'), true);

  // Invalid numbers
  assert.equal(validateRomanianPhone('123456'), false);
  assert.equal(validateRomanianPhone('0212345678'), false);
  assert.equal(validateRomanianPhone(''), false);
});

test('validateEmail correctly validates email addresses', () => {
  assert.equal(validateEmail('client@frizerie.ro'), true);
  assert.equal(validateEmail('alex.popa@gmail.com'), true);
  assert.equal(validateEmail('not-an-email'), false);
  assert.equal(validateEmail(''), false);
});

test('generateBookingReference produces expected FRZ prefix', () => {
  const fixedDate = new Date('2026-06-15');
  const ref = generateBookingReference(fixedDate);
  assert.match(ref, /^FRZ-2026-\d{4}$/);
});

test('calculateBarberEstimate correctly adds base haircut price, addons and extra duration', () => {
  const baseHaircutPrice = 70;
  const addons = {
    hotTowelTreatment: true,
    blackMask: true,
  };

  const result = calculateBarberEstimate(baseHaircutPrice, 40, addons);
  assert.equal(result.basePrice, 70);
  assert.equal(result.addonsTotal, 60);
  assert.equal(result.finalTotal, 130);
  assert.equal(result.totalDurationMin, 65);
});

test('AVAILABLE_TIME_SLOTS contains regular working hours (L-V 09:00 - 16:00, S 09:00 - 13:00)', () => {
  assert.ok(AVAILABLE_TIME_SLOTS.includes('09:00'));
  assert.ok(AVAILABLE_TIME_SLOTS.includes('12:00'));
  assert.ok(AVAILABLE_TIME_SLOTS.includes('15:00'));
  assert.ok(AVAILABLE_TIME_SLOTS.length >= 8);

  // Saturday check (Nov 7 2026 is a Saturday)
  const satSlots = getTimeSlotsForDate('2026-11-07');
  assert.ok(satSlots.includes('09:00'));
  assert.ok(satSlots.includes('12:30'));
  assert.equal(satSlots.includes('15:00'), false);

  // Sunday check (Nov 8 2026 is a Sunday - Closed)
  const sunSlots = getTimeSlotsForDate('2026-11-08');
  assert.equal(sunSlots.length, 0);
});

test('formatRon produces valid currency output', () => {
  const formatted = formatRon(120);
  assert.ok(formatted.includes('120'));
  assert.ok(formatted.includes('RON') || formatted.includes('lei'));
});

test('formatRomanianDate produces Romanian month names', () => {
  const formatted = formatRomanianDate('2026-08-15');
  assert.ok(formatted.includes('august'));
  assert.ok(formatted.includes('2026'));
});

test('formatRomanianDateWithDay includes weekday and Romanian month', () => {
  // 2026-11-23 is Monday
  const formatted = formatRomanianDateWithDay('2026-11-23');
  assert.ok(formatted.toLowerCase().includes('luni'));
  assert.ok(formatted.toLowerCase().includes('noiembrie'));
  assert.ok(formatted.includes('2026'));
});

test('isValidSupabaseUrl and isValidSupabaseKey validate format', () => {
  assert.equal(isValidSupabaseUrl('https://xyzbarbershop.supabase.co'), true);
  assert.equal(isValidSupabaseUrl('https://example.com'), false);
  assert.equal(isValidSupabaseKey('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh5eiJ9.abc123sign'), true);
});

test('getSecurityAudit returns security policies for all tables including auth audit and pfa settings', () => {
  const audit = getSecurityAudit();
  assert.equal(audit.length, 5);
  const tables = audit.map(a => a.tableName);
  assert.ok(tables.includes('bookings'));
  assert.ok(tables.includes('reviews'));
  assert.ok(tables.includes('gallery_items'));
  assert.ok(tables.includes('admin_auth_audit'));
  assert.ok(tables.includes('pfa_settings'));
});

test('hashPassword and verifyPassword work cryptographically', async () => {
  const password = 'TestPassword2026!';
  const hash = await hashPassword(password);
  assert.ok(hash.length >= 32);

  const isValid = await verifyPassword(password, hash);
  assert.equal(isValid, true);

  const isInvalid = await verifyPassword('WrongPassword', hash);
  assert.equal(isInvalid, false);
});

test('createAdminSession produces valid token and expiration', () => {
  const session = createAdminSession('admin@roxanateusde.ro');
  assert.equal(session.username, 'admin@roxanateusde.ro');
  assert.equal(session.role, 'admin');
  assert.equal(validateAdminSession(session), true);

  const expiredSession = { ...session, expiresAt: Date.now() - 1000 };
  assert.equal(validateAdminSession(expiredSession), false);
});

test('mapsUtils calculates route to Str. Plopilor 28', () => {
  const preset = PRESET_ORIGINS[0];
  assert.ok(preset.distanceKm > 0);
  assert.ok(preset.durationDriveMin > 0);

  const navUrl = getGoogleMapsDirectionsUrl('Tileagd (Centru)');
  assert.ok(navUrl.includes('47.0720225') && navUrl.includes('22.1974235'));
  assert.equal(getGoogleMapsDirectionsUrl(), 'https://maps.app.goo.gl/5VWHefyfAgicsNBn6');

  const dynamic = calculateDynamicRoute('Salonta, Bihor');
  assert.ok(dynamic.distanceKm > 0);
  assert.ok(dynamic.turnByTurn.length > 0);
});
