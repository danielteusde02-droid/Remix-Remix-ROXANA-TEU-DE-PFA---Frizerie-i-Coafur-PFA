/**
 * Pure utility functions for ROXANA TEUSDE PFA - Frizerie & Barbershop
 * Barbershop appointment validations, calculations, reference generators, and currency formatters.
 */

export interface BarbershopAddons {
  hotTowelTreatment?: boolean;
  hairWashStyling?: boolean;
  blackMask?: boolean;
  beardCamouflage?: boolean;
  headMassage?: boolean;
  eyebrowStyling?: boolean;
  [key: string]: boolean | undefined;
}

export const BARBERSHOP_ADDON_PRICES: Record<keyof BarbershopAddons, { name: string; priceRon: number; durationMin: number }> = {
  hotTowelTreatment: { name: 'Tratament cu prosop cald și uleiuri esențiale', priceRon: 25, durationMin: 10 },
  hairWashStyling: { name: 'Spălat dublu revitalizant + Styling profesional', priceRon: 20, durationMin: 10 },
  blackMask: { name: 'Mască neagră detoxifiantă cu cărbune activ (Black Mask)', priceRon: 35, durationMin: 15 },
  beardCamouflage: { name: 'Camuflaj & nuanțare fire albe barbă', priceRon: 40, durationMin: 15 },
  headMassage: { name: 'Masaj capilar relaxant cu tonic mentolat', priceRon: 30, durationMin: 10 },
  eyebrowStyling: { name: 'Stilizare & conturare sprâncene', priceRon: 15, durationMin: 5 },
};

/**
 * Official Working Hours for Frizerie & Coafură Roxana Teușde PFA (Buie):
 * - Luni – Vineri: 09:00 – 16:00
 * - Sâmbătă: 09:00 – 13:00
 * - Duminică: Închis
 */
export const WEEKDAY_TIME_SLOTS = [
  '09:00', '09:45', '10:30', '11:15', '12:00', '12:45', '13:30', '14:15', '15:00', '15:30'
];

export const SATURDAY_TIME_SLOTS = [
  '09:00', '09:45', '10:30', '11:15', '12:00', '12:30'
];

export const AVAILABLE_TIME_SLOTS = WEEKDAY_TIME_SLOTS;

/**
 * Returns available booking slots based on the chosen day of the week
 */
export function getTimeSlotsForDate(dateString: string): string[] {
  if (!dateString) return WEEKDAY_TIME_SLOTS;
  const parts = dateString.split('-');
  if (parts.length !== 3) return WEEKDAY_TIME_SLOTS;
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);
  const dateObj = new Date(year, month, day);
  const dayOfWeek = dateObj.getDay(); // 0: Duminică, 6: Sâmbătă

  if (dayOfWeek === 0) {
    return []; // Duminică este închis
  }
  if (dayOfWeek === 6) {
    return SATURDAY_TIME_SLOTS; // Sâmbătă până la ora 13:00
  }
  return WEEKDAY_TIME_SLOTS; // Luni - Vineri: 09:00 - 16:00
}

/**
 * Validates Romanian phone number format (accepts 07xxxxxxxx, +407xxxxxxxx, 00407xxxxxxxx, with or without spaces/dashes)
 */
export function validateRomanianPhone(phone: string): boolean {
  if (!phone) return false;
  const clean = phone.replace(/[\s\-\.\(\)]/g, '');
  const roPhoneRegex = /^(?:(?:\+40|0040)|0)7[0-9]{8}$/;
  return roPhoneRegex.test(clean);
}

/**
 * Validates email address format
 */
export function validateEmail(email: string): boolean {
  if (!email) return false;
  const trimmed = email.trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  return emailRegex.test(trimmed);
}

/**
 * Generates a unique frizerie appointment reference code (e.g., FRZ-2026-7842)
 */
export function generateBookingReference(date = new Date()): string {
  const year = date.getFullYear();
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  return `FRZ-${year}-${randomSuffix}`;
}

/**
 * Calculates total appointment cost and duration based on service price and chosen addons
 */
export function calculateBarberEstimate(
  baseServicePriceRon: number,
  baseDurationMin = 30,
  addons: BarbershopAddons = {},
  addonCatalog?: Array<{ id: string; priceRon: number; durationMin: number }>
): {
  basePrice: number;
  addonsTotal: number;
  finalTotal: number;
  totalDurationMin: number;
} {
  const basePrice = Math.max(0, baseServicePriceRon);
  let addonsTotal = 0;
  let extraDuration = 0;

  for (const [key, enabled] of Object.entries(addons)) {
    if (enabled) {
      if (addonCatalog && addonCatalog.length > 0) {
        const item = addonCatalog.find(a => a.id === key);
        if (item) {
          addonsTotal += item.priceRon;
          extraDuration += item.durationMin;
          continue;
        }
      }
      if (BARBERSHOP_ADDON_PRICES[key as keyof BarbershopAddons]) {
        addonsTotal += BARBERSHOP_ADDON_PRICES[key as keyof BarbershopAddons].priceRon;
        extraDuration += BARBERSHOP_ADDON_PRICES[key as keyof BarbershopAddons].durationMin;
      }
    }
  }

  const finalTotal = basePrice + addonsTotal;
  const totalDurationMin = baseDurationMin + extraDuration;

  return {
    basePrice,
    addonsTotal,
    finalTotal,
    totalDurationMin,
  };
}

/**
 * Formats RON currency
 */
export function formatRon(amount: number): string {
  return new Intl.NumberFormat('ro-RO', {
    style: 'currency',
    currency: 'RON',
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Formats a Romanian date (e.g. "18 iulie 2026")
 */
export function formatRomanianDate(dateString: string): string {
  if (!dateString) return '';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;

  return new Intl.DateTimeFormat('ro-RO', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(date);
}

/**
 * Formats a Romanian date with the day of the week (e.g. "Luni, 23 noiembrie 2026")
 */
export function formatRomanianDateWithDay(dateString: string): string {
  if (!dateString) return '';
  const parts = dateString.split('-');
  if (parts.length !== 3) return dateString;
  const date = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
  if (isNaN(date.getTime())) return dateString;

  const dayNames = ['Duminică', 'Luni', 'Marți', 'Miercuri', 'Joi', 'Vineri', 'Sâmbătă'];
  const monthNames = [
    'ianuarie', 'februarie', 'martie', 'aprilie', 'mai', 'iunie',
    'iulie', 'august', 'septembrie', 'octombrie', 'noiembrie', 'decembrie'
  ];

  const dayName = dayNames[date.getDay()];
  const dayNum = date.getDate();
  const monthName = monthNames[date.getMonth()];
  const year = date.getFullYear();

  return `${dayName}, ${dayNum} ${monthName} ${year}`;
}
