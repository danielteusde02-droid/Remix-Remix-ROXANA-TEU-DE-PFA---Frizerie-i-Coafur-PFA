/**
 * Secure Authentication & Cryptographic Hashing Utilities
 * for ROXANA TEUSDE PFA (BUIE) Administrator
 */

import { getSupabase } from '../lib/supabase';

export interface AdminSession {
  token: string;
  username: string;
  role: 'admin';
  createdAt: number;
  expiresAt: number;
}

export interface AuthAttemptLog {
  id: string;
  username: string;
  status: 'SUCCESS' | 'FAILED' | 'LOGOUT';
  timestamp: string;
  userAgent: string;
  city: string;
  failureReason?: string;
}

export const AUTH_CONFIG = {
  DEFAULT_ADMIN_USER: 'admin@roxanateusde.ro',
  // Salt and SHA-256 pre-computed hash for default credential: Roxana2026!#
  SALT: 'roxana_buie_pfa_salt_2026',
  // SHA-256 hash of "Roxana2026!#" + "roxana_buie_pfa_salt_2026"
  // Computed via Web Crypto API SHA-256
  SESSION_STORAGE_KEY: 'rxt_admin_auth_session',
  AUDIT_STORAGE_KEY: 'rxt_auth_audit_logs',
  SESSION_DURATION_MS: 24 * 60 * 60 * 1000, // 24 hours
};

/**
 * Hashes a plaintext password using SHA-256 with salt via Web Crypto API or Node crypto
 */
export async function hashPassword(password: string, salt = AUTH_CONFIG.SALT): Promise<string> {
  const salted = `${password}:::${salt}`;

  if (typeof crypto !== 'undefined' && crypto.subtle && crypto.subtle.digest) {
    const encoder = new TextEncoder();
    const data = encoder.encode(salted);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  // Fallback for Node test runner
  try {
    const nodeCrypto = await import('node:crypto');
    return nodeCrypto.createHash('sha256').update(salted).digest('hex');
  } catch {
    // Basic fallback hash for environment without crypto
    let hash = 0;
    for (let i = 0; i < salted.length; i++) {
      hash = (hash << 5) - hash + salted.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash).toString(16);
  }
}

/**
 * Verifies a plaintext password against a stored SHA-256 hash
 */
export async function verifyPassword(password: string, storedHash: string, salt = AUTH_CONFIG.SALT): Promise<boolean> {
  if (!password || !storedHash) return false;
  const computed = await hashPassword(password, salt);
  return computed.toLowerCase() === storedHash.toLowerCase();
}

/**
 * Creates an authenticated session object
 */
export function createAdminSession(username: string): AdminSession {
  const now = Date.now();
  const randomSuffix = Math.random().toString(36).substring(2, 15);
  return {
    token: `rxt_sess_${now}_${randomSuffix}`,
    username: username.trim().toLowerCase(),
    role: 'admin',
    createdAt: now,
    expiresAt: now + AUTH_CONFIG.SESSION_DURATION_MS,
  };
}

/**
 * Validates whether an admin session is currently active and not expired
 */
export function validateAdminSession(session: AdminSession | null | undefined): boolean {
  if (!session) return false;
  if (session.role !== 'admin') return false;
  if (!session.token || !session.username) return false;
  return Date.now() < session.expiresAt;
}

/**
 * Persists session in localStorage / sessionStorage
 */
export function saveAdminSession(session: AdminSession): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    window.localStorage.setItem(AUTH_CONFIG.SESSION_STORAGE_KEY, JSON.stringify(session));
  } catch (err) {
    console.warn('Could not store session in localStorage', err);
  }
}

/**
 * Retrieves persisted session from storage and validates expiration
 */
export function getStoredAdminSession(): AdminSession | null {
  if (typeof window === 'undefined' || !window.localStorage) return null;
  try {
    const raw = window.localStorage.getItem(AUTH_CONFIG.SESSION_STORAGE_KEY);
    if (!raw) return null;
    const session: AdminSession = JSON.parse(raw);
    if (validateAdminSession(session)) {
      return session;
    }
    clearAdminSession();
    return null;
  } catch {
    return null;
  }
}

/**
 * Clears stored admin session
 */
export function clearAdminSession(): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    window.localStorage.removeItem(AUTH_CONFIG.SESSION_STORAGE_KEY);
  } catch (err) {
    console.warn('Could not clear session', err);
  }
}

/**
 * Logs an authentication attempt (SUCCESS or FAILED) to Supabase and Local Storage audit table
 */
export async function logAuthAttempt(attempt: Omit<AuthAttemptLog, 'id' | 'timestamp'>): Promise<AuthAttemptLog> {
  const fullLog: AuthAttemptLog = {
    ...attempt,
    id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `auth-${Date.now()}`,
    timestamp: new Date().toISOString(),
  };

  // 1. Try logging to Supabase table `admin_auth_audit`
  const supabase = getSupabase();
  if (supabase) {
    try {
      await supabase.from('admin_auth_audit').insert({
        username: fullLog.username,
        status: fullLog.status,
        timestamp: fullLog.timestamp,
        user_agent: fullLog.userAgent,
        city: fullLog.city,
        failure_reason: fullLog.failureReason || null,
      });
    } catch (err) {
      console.warn('Could not write auth audit to Supabase, saving locally', err);
    }
  }

  // 2. Persist in local storage audit log
  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      const raw = window.localStorage.getItem(AUTH_CONFIG.AUDIT_STORAGE_KEY);
      const logs: AuthAttemptLog[] = raw ? JSON.parse(raw) : [];
      window.localStorage.setItem(AUTH_CONFIG.AUDIT_STORAGE_KEY, JSON.stringify([fullLog, ...logs.slice(0, 100)]));
    } catch {
      // Ignore storage write issues
    }
  }

  return fullLog;
}

/**
 * Retrieves the security audit logs from Supabase or Local Storage
 */
export async function getAuthAuditLogs(): Promise<AuthAttemptLog[]> {
  const supabase = getSupabase();
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('admin_auth_audit')
        .select('*')
        .order('timestamp', { ascending: false })
        .limit(50);

      if (!error && data && data.length > 0) {
        return data.map((d: any) => ({
          id: d.id,
          username: d.username,
          status: d.status,
          timestamp: d.timestamp,
          userAgent: d.user_agent || d.userAgent || '',
          city: d.city || 'Tileagd, Bihor',
          failureReason: d.failure_reason || d.failureReason,
        }));
      }
    } catch {
      // Fallback
    }
  }

  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      const raw = window.localStorage.getItem(AUTH_CONFIG.AUDIT_STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch {
      // Fallback
    }
  }

  // Initial seed audit logs for demonstration
  return [
    {
      id: 'auth-seed-1',
      username: 'admin@roxanateusde.ro',
      status: 'SUCCESS',
      timestamp: new Date(Date.now() - 40 * 60000).toISOString(),
      userAgent: 'Chrome 131 / Windows Desktop',
      city: 'Tileagd, Bihor',
    },
    {
      id: 'auth-seed-2',
      username: 'unknown_guest',
      status: 'FAILED',
      timestamp: new Date(Date.now() - 180 * 60000).toISOString(),
      userAgent: 'Safari Mobile / iPhone iOS',
      city: 'Tileagd, Bihor',
      failureReason: 'Parolă invalidă',
    },
  ];
}
