import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Configuration keys
const STORAGE_KEY_URL = 'roxana_teusde_supabase_url';
const STORAGE_KEY_ANON = 'roxana_teusde_supabase_anon_key';

let cachedClient: SupabaseClient | null = null;
let cachedConfigString = '';

/**
 * Retrieves the current Supabase configuration, prioritizing environment variables,
 * then falling back to localStorage saved by the admin in the dashboard.
 */
export function getSupabaseCredentials(): { url: string; anonKey: string } {
  const envUrl = typeof import.meta !== 'undefined' && import.meta.env ? (import.meta.env.VITE_SUPABASE_URL || '') : '';
  const envKey = typeof import.meta !== 'undefined' && import.meta.env ? (import.meta.env.VITE_SUPABASE_ANON_KEY || '') : '';

  let storedUrl = '';
  let storedKey = '';

  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      storedUrl = window.localStorage.getItem(STORAGE_KEY_URL) || '';
      storedKey = window.localStorage.getItem(STORAGE_KEY_ANON) || '';
    } catch {
      // Ignore localStorage access restrictions
    }
  }

  return {
    url: (envUrl || storedUrl).trim(),
    anonKey: (envKey || storedKey).trim(),
  };
}

/**
 * Saves Supabase credentials to localStorage
 */
export function saveSupabaseCredentials(url: string, anonKey: string): void {
  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      window.localStorage.setItem(STORAGE_KEY_URL, url.trim());
      window.localStorage.setItem(STORAGE_KEY_ANON, anonKey.trim());
      cachedClient = null; // Invalidate cache
      cachedConfigString = '';
    } catch (err) {
      console.warn('Could not save to localStorage', err);
    }
  }
}

/**
 * Returns a configured Supabase client if valid credentials exist, or null.
 */
export function getSupabase(): SupabaseClient | null {
  const { url, anonKey } = getSupabaseCredentials();

  if (!url || !anonKey) {
    return null;
  }

  const configSignature = `${url}:::${anonKey}`;
  if (cachedClient && cachedConfigString === configSignature) {
    return cachedClient;
  }

  try {
    cachedClient = createClient(url, anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
    cachedConfigString = configSignature;
    return cachedClient;
  } catch (err) {
    console.error('Failed to create Supabase client:', err);
    return null;
  }
}

export interface ConnectionTestResult {
  success: boolean;
  message: string;
  isConfigured: boolean;
  hasTables?: boolean;
}

/**
 * Tests live connection to Supabase
 */
export async function testSupabaseConnection(overrideUrl?: string, overrideKey?: string): Promise<ConnectionTestResult> {
  const url = overrideUrl !== undefined ? overrideUrl.trim() : getSupabaseCredentials().url;
  const anonKey = overrideKey !== undefined ? overrideKey.trim() : getSupabaseCredentials().anonKey;

  if (!url || !anonKey) {
    return {
      success: false,
      isConfigured: false,
      message: 'Supabase nu este configurat încă. Aplicația folosește modul de stocare local sincronizat (100% funcțional).',
    };
  }

  try {
    const tempClient = createClient(url, anonKey);
    // Try pinging bookings table
    const { error } = await tempClient.from('bookings').select('count', { count: 'exact', head: true });

    if (error) {
      if (error.code === 'PGRST116' || error.message.includes('relation "public.bookings" does not exist') || error.message.includes('does not exist')) {
        return {
          success: true,
          isConfigured: true,
          hasTables: false,
          message: 'Conectat la Supabase! Notă: Tabelele nu au fost create încă. Folosiți scriptul SQL de mai jos pentru a le inițializa.',
        };
      }
      return {
        success: false,
        isConfigured: true,
        message: `Eroare conexiune: ${error.message} (${error.code || 'Necunoscut'})`,
      };
    }

    return {
      success: true,
      isConfigured: true,
      hasTables: true,
      message: 'Conexiune reușită! Baza de date Supabase este activă și comunică normal.',
    };
  } catch (err: any) {
    return {
      success: false,
      isConfigured: true,
      message: `Eroare la conectare: ${err?.message || 'Verificați URL-ul și cheia anonimă.'}`,
    };
  }
}
